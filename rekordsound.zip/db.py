"""Analysis database (data/library.db). Keyed by audio file path; Rekordbox metadata stays in the XML."""
import json
import sqlite3
from pathlib import Path

import numpy as np

from models import CLAP_DIM, EFFNET_DIM, MERT_DIM, N_STYLES, standardize

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "library.db"


def connect(path=None):
    path = Path(path) if path else DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")          # lets the app read while analyze.py writes
    con.execute("""CREATE TABLE IF NOT EXISTS audio (
        key TEXT PRIMARY KEY,            -- library.path_key(path)
        path TEXT, mtime REAL, size INTEGER, duration REAL,
        clap BLOB, clap_clips BLOB, mert BLOB, mert_clips BLOB, clip_starts TEXT,
        analyzed_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    have = {r[1] for r in con.execute("PRAGMA table_info(audio)")}
    for col in ("effnet", "effnet_clips", "styles"):            # discogs-effnet (added 2026-11-06)
        if col not in have:
            con.execute(f"ALTER TABLE audio ADD COLUMN {col} BLOB")
    con.execute("""CREATE TABLE IF NOT EXISTS failed (
        key TEXT PRIMARY KEY, path TEXT, mtime REAL, error TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    # genres.py: predicted DJ genre per file, and original tag values before genres.py wrote to a file
    con.execute("""CREATE TABLE IF NOT EXISTS genre_pred (
        key TEXT PRIMARY KEY, genre TEXT, second TEXT, confidence REAL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS genre_backup (
        key TEXT PRIMARY KEY, path TEXT, original TEXT, written TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    # energy.py: measured features per file and the 1-10 score derived from them
    con.execute("""CREATE TABLE IF NOT EXISTS energy (
        key TEXT PRIMARY KEY, mtime REAL, size INTEGER, feats TEXT, score REAL)""")
    # app-side playlists (editable copies; Rekordbox itself is never written). Tracks are stored by path key.
    con.execute("""CREATE TABLE IF NOT EXISTS playlist (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, source TEXT,
        created TEXT DEFAULT CURRENT_TIMESTAMP, updated TEXT DEFAULT CURRENT_TIMESTAMP)""")
    con.execute("""CREATE TABLE IF NOT EXISTS playlist_track (
        playlist_id INTEGER NOT NULL, pos INTEGER NOT NULL, key TEXT NOT NULL, PRIMARY KEY (playlist_id, pos))""")
    con.commit()
    return con


# ---------------------------------------------------------------- app playlists
def list_playlists(con):
    """-> [dict(id, name, source, count)]"""
    return [dict(id=i, name=n, source=s, count=c) for i, n, s, c in con.execute(
        "SELECT p.id, p.name, p.source, (SELECT COUNT(*) FROM playlist_track t WHERE t.playlist_id = p.id) "
        "FROM playlist p ORDER BY p.name COLLATE NOCASE")]


def get_playlist(con, pid):
    """-> (dict(id, name, source), [keys in order]) or None"""
    r = con.execute("SELECT id, name, source FROM playlist WHERE id=?", (pid,)).fetchone()
    if not r:
        return None
    keys = [k for (k,) in con.execute("SELECT key FROM playlist_track WHERE playlist_id=? ORDER BY pos", (pid,))]
    return dict(id=r[0], name=r[1], source=r[2]), keys


def create_playlist(con, name, keys=(), source=None):
    cur = con.execute("INSERT INTO playlist (name, source) VALUES (?,?)", (name, source))
    pid = cur.lastrowid
    con.executemany("INSERT INTO playlist_track (playlist_id, pos, key) VALUES (?,?,?)",
                    [(pid, i, k) for i, k in enumerate(keys)])
    con.commit()
    return pid


def rename_playlist(con, pid, name):
    n = con.execute("UPDATE playlist SET name=?, updated=CURRENT_TIMESTAMP WHERE id=?", (name, pid)).rowcount
    con.commit()
    return n > 0


def delete_playlist(con, pid):
    n = con.execute("DELETE FROM playlist WHERE id=?", (pid,)).rowcount
    con.execute("DELETE FROM playlist_track WHERE playlist_id=?", (pid,))
    con.commit()
    return n > 0


def set_playlist_keys(con, pid, keys):
    """Replace the ordered track list (used for add, remove and reorder)."""
    if not con.execute("SELECT 1 FROM playlist WHERE id=?", (pid,)).fetchone():
        return False
    con.execute("DELETE FROM playlist_track WHERE playlist_id=?", (pid,))
    con.executemany("INSERT INTO playlist_track (playlist_id, pos, key) VALUES (?,?,?)",
                    [(pid, i, k) for i, k in enumerate(keys)])
    con.execute("UPDATE playlist SET updated=CURRENT_TIMESTAMP WHERE id=?", (pid,))
    con.commit()
    return True


def playlists_by_key(con):
    """-> {track key: [(playlist id, name) of my playlists containing it]}"""
    out = {}
    for k, i, n in con.execute("SELECT t.key, p.id, p.name FROM playlist_track t JOIN playlist p ON p.id = t.playlist_id "
                               "ORDER BY p.name COLLATE NOCASE"):
        out.setdefault(k, []).append((i, n))
    return out


def analysed_keys(con):
    return {k for (k,) in con.execute("SELECT key FROM audio")}


def save_energy(con, key, mtime, size, feats, score):
    con.execute("INSERT OR REPLACE INTO energy (key, mtime, size, feats, score) VALUES (?,?,?,?,?)",
                (key, mtime, size, json.dumps(feats), score))
    con.commit()


def load_energy(con):
    """-> [(key, feats dict, score or None)]"""
    return [(k, json.loads(f), s) for k, f, s in con.execute("SELECT key, feats, score FROM energy")]


def f32(a):
    return np.asarray(a, np.float32).tobytes()


def f16(a):
    return np.asarray(a, np.float16).tobytes()


def save(con, key, path, mtime, size, duration, r):
    con.execute("INSERT OR REPLACE INTO audio (key, path, mtime, size, duration, clap, clap_clips, mert, "
                "mert_clips, clip_starts, effnet, effnet_clips, styles) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (key, path, mtime, size, duration, f32(r["clap"]), f32(r["clap_clips"]), f32(r["mert"]),
                 f32(r["mert_clips"]), json.dumps(r["clip_starts"]), f32(r["effnet"]), f16(r["effnet_clips"]),
                 f16(r["styles"])))
    con.execute("DELETE FROM failed WHERE key=?", (key,))
    con.commit()


def save_effnet(con, key, r):
    """Add discogs-effnet results to a track that was analysed before effnet existed."""
    con.execute("UPDATE audio SET effnet=?, effnet_clips=?, styles=? WHERE key=?",
                (f32(r["effnet"]), f16(r["effnet_clips"]), f16(r["styles"]), key))
    con.commit()


def load_vectors():
    """-> dict(keys, duration, E (CLAP unit vectors), C (list of CLAP clip matrices, float16), clip_starts,
               M (standardized MERT unit vectors), M_raw, mert_mu, mert_sd,
               F (centred discogs-effnet unit vectors, zero rows where missing), F_raw, eff_mu, has_effnet (mask),
               S (400 Discogs style probabilities, float16))"""
    con = connect()
    rows = con.execute("SELECT key, duration, clap, clap_clips, clip_starts, mert, effnet, styles FROM audio").fetchall()
    con.close()
    n = len(rows)
    E = np.zeros((n, CLAP_DIM), np.float32)
    M_raw = np.zeros((n, MERT_DIM), np.float32)
    F_raw = np.zeros((n, EFFNET_DIM), np.float32)
    S = np.zeros((n, N_STYLES), np.float16)
    has_effnet = np.zeros(n, bool)
    C, starts = [], []
    for i, r in enumerate(rows):
        E[i] = np.frombuffer(r[2], np.float32)
        M_raw[i] = np.frombuffer(r[5], np.float32)
        C.append(np.frombuffer(r[3], np.float32).reshape(-1, CLAP_DIM).astype(np.float16))
        starts.append(json.loads(r[4]))
        if r[6] is not None:
            F_raw[i] = np.frombuffer(r[6], np.float32)
            S[i] = np.frombuffer(r[7], np.float16)
            has_effnet[i] = True
    mu, sd = np.zeros(MERT_DIM, np.float32), np.ones(MERT_DIM, np.float32)
    has_mert = n >= 20                     # need a reasonable sample for the statistics
    M = np.zeros_like(M_raw)
    if has_mert:
        mu, sd = M_raw.mean(0), M_raw.std(0) + 1e-6
        M = standardize(M_raw, mu, sd).astype(np.float32)
    eff_mu = F_raw[has_effnet].mean(0) if has_effnet.sum() >= 20 else np.zeros(EFFNET_DIM, np.float32)
    F = np.zeros_like(F_raw)
    F[has_effnet] = center(F_raw[has_effnet], eff_mu)
    return dict(keys=[r[0] for r in rows], duration=[r[1] for r in rows], E=E, C=C, clip_starts=starts,
                M=M, M_raw=M_raw, has_mert=has_mert, mert_mu=mu, mert_sd=sd,
                F=F, F_raw=F_raw, eff_mu=eff_mu, has_effnet=has_effnet, S=S)


def center(x, mu):
    """Raw effnet vector(s) -> library-centred unit vector(s). Effnet vectors share a large common component;
    removing the library mean spreads similarities out (queries use the same mean)."""
    z = x - mu
    return (z / (np.linalg.norm(z, axis=-1, keepdims=True) + 1e-9)).astype(np.float32)
