"""Read-only parser for a Rekordbox XML export (File -> Export Collection in xml format).

    python library.py [path/to/rekordbox.xml]     -> summary + list of missing files
"""
import ntpath
import os
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent
DEFAULT_XML = ROOT / "data" / "rekordbox.xml"
AUDIO_EXT = {".mp3", ".wav", ".aif", ".aiff", ".flac", ".m4a", ".mp4", ".aac", ".ogg", ".alac", ".wma"}

# ------------------------------------------------------------------ keys (Camelot)
_PC = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def camelot(tonality: str | None) -> str | None:
    """Rekordbox 'Tonality' ('Am', 'F#m', 'Db', 'Abm', '8A', '12B', ...) -> Camelot code ('8A') or None."""
    s = (tonality or "").strip()
    if not s:
        return None
    m = re.fullmatch(r"(1[0-2]|[1-9])\s*([AaBb])", s)
    if m:
        return f"{int(m.group(1))}{m.group(2).upper()}"
    m = re.fullmatch(r"([A-Ga-g])\s*([#♯b♭]?)\s*(m|min|minor|maj|major)?", s)
    if not m:
        return None
    pc = _PC[m.group(1).upper()] + {"#": 1, "♯": 1, "b": -1, "♭": -1}.get(m.group(2), 0)
    minor = (m.group(3) or "").lower() in ("m", "min", "minor")
    # each step around the circle of fifths (+7 semitones) is +1 on the Camelot wheel; Am = 8A, C = 8B
    n = (8 + 7 * ((pc - 9) if minor else pc) - 1) % 12 + 1
    return f"{n}{'A' if minor else 'B'}"


def camelot_neighbours(code: str | None) -> set[str]:
    """Harmonically compatible keys: same, +-1 on the wheel, and the relative major/minor."""
    if not code:
        return set()
    n, letter = int(code[:-1]), code[-1]
    other = "B" if letter == "A" else "A"
    return {code, f"{n % 12 + 1}{letter}", f"{(n - 2) % 12 + 1}{letter}", f"{n}{other}"}


# ------------------------------------------------------------------ genres
# Genre names that contain a separator character and must not be split.
_PROTECTED = {"folk, world, & country": "Folk, World, & Country", "funk / soul": "Funk / Soul"}
# lower-case spelling -> canonical name ("" = drop)
GENRE_ALIASES = {
    "elektronička glazba": "Electronic", "electrónica": "Electronic", "electronica": "Electronic",
    "elecronic": "Electronic", "electronic music": "Electronic",
    "synthpop": "Synth-pop", "synth.pop": "Synth-pop", "synth pop": "Synth-pop",
    "nu disco": "Nu-Disco", "nudisco": "Nu-Disco", "italo disco": "Italo-Disco", "italo": "Italo-Disco",
    "hip-hop": "Hip Hop", "hiphop": "Hip Hop", "rnb": "R&B", "rnb/swing": "R&B", "rhythm & blues": "R&B",
    "chill-out": "Downtempo", "chillout": "Downtempo", "chill out": "Downtempo", "downbeat": "Downtempo",
    "jazz funk": "Jazz-Funk", "jazz & funk": "Jazz-Funk", "jazz-funk": "Jazz-Funk",
    "soul & funk": "Funk / Soul", "soul and funk": "Funk / Soul",
    "euro-house": "Euro House", "brazilian music": "Brazilian", "african music": "African",
    "world music": "World", "musiques du monde": "World", "film soundtracks": "Soundtrack",
    "library music": "Library", "alternativa & indie": "Alternative & Indie", "stage and screen": "Stage & Screen",
    "re-edits": "Edits", "breakbeat": "Breaks", "jazz-fusion": "Fusion",
    "stage": "", "screen": "", "other": "", "miscellaneous": "",
}
GENERIC = {"Electronic", "Dance", "Pop", "Edits", "Dancefloor", "80s", "90s", "Instrumental"}
_canon_case = {}            # lower -> most common spelling, filled by load()


def split_genres(raw: str) -> list[str]:
    """'Electronic, Funk / Soul;Techno/House' -> ['Electronic', 'Funk / Soul', 'Techno', 'House']."""
    s = raw or ""
    for i, k in enumerate(_PROTECTED):
        s = re.sub(re.escape(k), f"\x00{i}\x00", s, flags=re.I)
    out = []
    for part in re.split(r"[;,/]", s):
        part = re.sub(r"\x00(\d)\x00", lambda m: list(_PROTECTED.values())[int(m.group(1))], part)
        part = re.sub(r"\.\d+$", "", part.strip(" .&"))           # 'rock.1' -> 'rock'
        if not part:
            continue
        low = part.lower()
        part = GENRE_ALIASES.get(low, _canon_case.get(low, part))
        if part:
            out.append(part)
    return list(dict.fromkeys(out))


def _build_case_map(raw_genres):
    from collections import Counter
    c = Counter()
    _canon_case.clear()
    for raw in raw_genres:
        c.update(split_genres(raw))
    for name, _ in c.most_common()[::-1]:          # most common spelling wins (written last)
        _canon_case[name.lower()] = name
    for k, v in _PROTECTED.items():
        _canon_case[k] = v


def is_specific(genres) -> bool:
    return any(g not in GENERIC for g in genres)


# ------------------------------------------------------------------ parsing
def location_to_path(loc: str) -> str | None:
    """'file://localhost/C:/Music/a%20b.mp3' -> 'C:\\Music\\a b.mp3'. Streaming entries -> None."""
    if not loc or not loc.startswith("file://"):
        return None
    p = unquote(loc[len("file://"):])
    if p.startswith("localhost"):
        p = p[len("localhost"):]
    if re.match(r"^/[A-Za-z]:", p):          # Windows drive letter
        p = p[1:]
    return os.path.normpath(p)


def path_key(path: str) -> str:
    """Key used to match analysed audio to library entries (case-insensitive on Windows)."""
    return ntpath.normcase(ntpath.normpath(path))     # Windows rules on every OS (the DB keys are Windows paths)


def _num(s, typ=float):
    try:
        v = typ(s)
        return v if v else None
    except (TypeError, ValueError):
        return None


def load(xml_path=DEFAULT_XML):
    """-> (tracks, playlists, skipped)
    tracks:    {track_id: dict(id, path, title, artist, album, genre, label, bpm, key, camelot, year,
                               rating (0-5), comments, duration, kind, date_added, playlists=[ids])}
    playlists: [dict(id, name, path ('Folder / Name'), track_ids=[...])]   (only real playlists, not folders)
    skipped:   number of collection entries without a local file (streaming tracks)."""
    xml_path = Path(xml_path)
    if not xml_path.exists():
        raise FileNotFoundError(f"Rekordbox XML not found: {xml_path}\n"
                                "Export it in Rekordbox via File -> Export Collection in xml format.")
    root = ET.parse(xml_path).getroot()
    tracks, by_loc, skipped = {}, {}, 0
    for t in root.iterfind("COLLECTION/TRACK"):
        a = t.attrib
        path = location_to_path(a.get("Location", ""))
        if not path:
            skipped += 1
            continue
        tid = a.get("TrackID")
        rating = _num(a.get("Rating"), int) or 0
        tracks[tid] = dict(
            id=tid, path=path, title=a.get("Name") or Path(path).stem, artist=a.get("Artist", ""),
            album=a.get("Album", ""), genre=a.get("Genre", "").strip(), label=a.get("Label", ""),
            genres=[],
            bpm=_num(a.get("AverageBpm")), key=a.get("Tonality", "") or None,
            camelot=camelot(a.get("Tonality")), year=_num(a.get("Year"), int),
            rating=min(5, round(rating / 51)), comments=a.get("Comments", ""),
            duration=_num(a.get("TotalTime")), kind=a.get("Kind", ""), date_added=a.get("DateAdded", ""),
            playlists=[])
        by_loc[a.get("Location")] = tid
    _build_case_map(t["genre"] for t in tracks.values())
    for t in tracks.values():
        t["genres"] = split_genres(t["genre"])

    playlists = []

    def walk(node, prefix):
        for n in node.findall("NODE"):
            name = n.get("Name", "")
            if n.get("Type") == "0":                       # folder
                walk(n, prefix + [name])
                continue
            by_location = n.get("KeyType") == "1"
            ids = []
            for e in n.findall("TRACK"):
                k = e.get("Key")
                tid = by_loc.get(k) if by_location else k
                if tid in tracks:
                    ids.append(tid)
            pid = str(len(playlists))
            playlists.append(dict(id=pid, name=name, path=" / ".join(prefix + [name]), track_ids=ids))
            for tid in dict.fromkeys(ids):
                tracks[tid]["playlists"].append(pid)

    root_node = root.find("PLAYLISTS/NODE")
    if root_node is not None:
        walk(root_node, [])
    return tracks, playlists, skipped


def diff(old_tracks, old_playlists, new_tracks, new_playlists):
    """Compare two loaded collections by file path (TrackIDs and playlist ids change between exports).
    -> dict(added=[track], removed=[track], playlists_added=[path], playlists_removed=[path],
            playlists_changed=[dict(path, added, removed)])"""
    ok = {path_key(t["path"]): t for t in old_tracks.values()}
    nk = {path_key(t["path"]): t for t in new_tracks.values()}

    def keysets(tracks, playlists):
        return {p["path"]: {path_key(tracks[i]["path"]) for i in p["track_ids"]} for p in playlists}
    op, np_ = keysets(old_tracks, old_playlists), keysets(new_tracks, new_playlists)
    changed = []
    for path in sorted(op.keys() & np_.keys()):
        a, r = len(np_[path] - op[path]), len(op[path] - np_[path])
        if a or r:
            changed.append(dict(path=path, added=a, removed=r))
    return dict(added=[nk[k] for k in nk.keys() - ok.keys()], removed=[ok[k] for k in ok.keys() - nk.keys()],
                playlists_added=sorted(np_.keys() - op.keys()), playlists_removed=sorted(op.keys() - np_.keys()),
                playlists_changed=changed)


def missing(tracks):
    return [t for t in tracks.values() if not os.path.exists(t["path"])]


if __name__ == "__main__":
    xml = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_XML
    tracks, playlists, skipped = load(xml)
    miss = missing(tracks)
    exts = {}
    for t in tracks.values():
        e = Path(t["path"]).suffix.lower()
        exts[e] = exts.get(e, 0) + 1
    print(f"{len(tracks)} local tracks, {len(playlists)} playlists"
          + (f", {skipped} streaming/non-file entries skipped" if skipped else ""))
    print("formats: " + ", ".join(f"{e or '?'} {n}" for e, n in sorted(exts.items(), key=lambda x: -x[1])))
    print(f"with BPM {sum(t['bpm'] is not None for t in tracks.values())}, "
          f"with key {sum(t['camelot'] is not None for t in tracks.values())}, "
          f"with genre {sum(bool(t['genre']) for t in tracks.values())}")
    unparsed = sorted({t['key'] for t in tracks.values() if t['key'] and not t['camelot']})
    if unparsed:
        print("unrecognised Tonality values:", unparsed[:20])
    print(f"{len(miss)} missing files")
    for t in miss[:50]:
        print("  missing:", t["path"])
    if len(miss) > 50:
        print(f"  ... and {len(miss) - 50} more")
