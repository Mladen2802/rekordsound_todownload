#!/usr/bin/env bash
# rekordsound on macOS: double-click this file. The first time it installs everything (a few minutes), after that it just starts the app.
# If macOS says it is "damaged" (it is not: it blocks files from the internet), open Terminal in this folder and run:
#   xattr -cr . && bash "Install and Start.command"
cd "$(dirname "$0")" || exit 1

pause_exit() { echo; read -n 1 -s -r -p "Press any key to close this window."; echo; exit "${1:-1}"; }

# Remove the "downloaded from the internet" flag from this folder so the other scripts do not trigger the same warning.
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x ./*.command ./*.sh 2>/dev/null

# Already running: just open the page.
if lsof -nP -iTCP:7870 -sTCP:LISTEN >/dev/null 2>&1; then
  open http://127.0.0.1:7870/
  exit 0
fi

if ! .venv/bin/python -c "import torch, fastapi, transformers" >/dev/null 2>&1; then
  echo "First start: installing what rekordsound needs (ffmpeg, Node, Python, the analysis models' libraries)."
  echo "This takes a few minutes and downloads about 1 GB. You can leave it running."
  echo

  # Homebrew: look in the usual places, offer to install it when missing.
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    [ -x "$b" ] && eval "$("$b" shellenv)" && break
  done
  if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew (the macOS package manager) is not installed. It is needed once, to install ffmpeg and Python."
    echo "It is installed with the official script from https://brew.sh and asks for your Mac password."
    read -r -p "Install Homebrew now? [y/N] " a
    case "$a" in
      [yY]*) /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || pause_exit 1 ;;
      *) echo "Cancelled. Install Homebrew from https://brew.sh, then double-click this file again."; pause_exit 1 ;;
    esac
    for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
      [ -x "$b" ] && eval "$("$b" shellenv)" && break
    done
    command -v brew >/dev/null 2>&1 || { echo "Homebrew was installed but is not on the PATH. Close this window and double-click again."; pause_exit 1; }
  fi

  bash ./setup-mac.sh || { echo; echo "Setup failed. The messages above say why; send them to whoever gave you this app."; pause_exit 1; }
fi

# A real app (~/Applications/rekordsound.app) with an icon: shows in Launchpad and Spotlight, can be dragged to the Dock, and a copy
# sits on the Desktop. Made here, on this Mac, so macOS does not flag it. Rewritten on each run, so a moved folder is fixed too.
make_app() {
  local app="$HOME/Applications/rekordsound.app" here="$PWD" tpl set
  mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources" || return 1
  tpl='#!/bin/bash
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
D="__DIR__"
cd "$D" || exit 1
if lsof -nP -iTCP:7870 -sTCP:LISTEN >/dev/null 2>&1; then open http://127.0.0.1:7870/; exit 0; fi
if [ ! -x .venv/bin/python ]; then open -a Terminal "$D/Install and Start.command"; exit 0; fi
exec .venv/bin/python app.py'
  printf '%s\n' "${tpl//__DIR__/$here}" > "$app/Contents/MacOS/rekordsound" && chmod +x "$app/Contents/MacOS/rekordsound"
  cat > "$app/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>rekordsound</string>
<key>CFBundleDisplayName</key><string>rekordsound</string>
<key>CFBundleIdentifier</key><string>local.rekordsound</string>
<key>CFBundleExecutable</key><string>rekordsound</string>
<key>CFBundleIconFile</key><string>icon</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
</dict></plist>
PLIST
  if [ -f assets/icon.png ] && command -v iconutil >/dev/null 2>&1; then          # icon.png (1024 px) -> icon.icns
    set="$(mktemp -d)/icon.iconset"; mkdir -p "$set"
    for s in 16 32 128 256 512; do
      sips -z $s $s assets/icon.png --out "$set/icon_${s}x${s}.png" >/dev/null 2>&1
      sips -z $((s*2)) $((s*2)) assets/icon.png --out "$set/icon_${s}x${s}@2x.png" >/dev/null 2>&1
    done
    iconutil -c icns "$set" -o "$app/Contents/Resources/icon.icns" 2>/dev/null
  fi
  touch "$app"                                                                    # make Finder / Launchpad pick up the icon
  # the old Desktop launcher (a plain script) is replaced by a link to the app
  [ -f "$HOME/Desktop/rekordsound.command" ] && grep -q 'Install and Start.command' "$HOME/Desktop/rekordsound.command" && rm -f "$HOME/Desktop/rekordsound.command"
  [ -d "$HOME/Desktop" ] && ln -sfn "$app" "$HOME/Desktop/rekordsound.app"
  echo "Added the rekordsound app to ~/Applications (Launchpad, Spotlight) and to the Desktop. Drag it to the Dock to keep it there."
}
make_app || echo "(could not create the app icon; start with Install and Start.command instead)"

echo
echo "Starting rekordsound at http://127.0.0.1:7870 (leave this window open while you use it; close it to stop)."
exec .venv/bin/python app.py
