"""Tempo estimate for a short audio clip (mic recording, YouTube link): numpy only.
Onset strength (positive log-spectral flux, low frequencies emphasised) -> autocorrelation -> tempo with a
dance-music prior. Octave errors (half / double time) are the usual failure; the half/double filter option covers them."""
import numpy as np

SR = 48000
HOP = 256
NFFT = 2048
MAX_SEC = 60


def onset_envelope(audio, sr=SR):
    n = len(audio)
    if n > MAX_SEC * sr:                                   # middle part only
        s = (n - MAX_SEC * sr) // 2
        audio = audio[s:s + MAX_SEC * sr]
    audio = np.asarray(audio, np.float32)
    nfr = 1 + (len(audio) - NFFT) // HOP
    if nfr < 50:
        return None, 0
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(nfr)[:, None]
    win = np.hanning(NFFT).astype(np.float32)
    mag = np.abs(np.fft.rfft(audio[idx] * win, axis=1))
    freqs = np.fft.rfftfreq(NFFT, 1 / sr)
    # 6 bands (bass .. hats) so a kick is not drowned by broadband noise
    edges = [30, 120, 300, 800, 2500, 6000, 12000]
    env = np.zeros(nfr - 1, np.float32)
    for lo, hi in zip(edges[:-1], edges[1:]):
        b = mag[:, (freqs >= lo) & (freqs < hi)].sum(1)
        lb = np.log1p(30 * b / (b.mean() + 1e-9))
        d = np.maximum(np.diff(lb), 0)
        env += d / (d.std() + 1e-9) * (1.5 if lo < 300 else 1.0)
    return env, sr / HOP


def estimate_bpm(audio, sr=SR, lo=70.0, hi=180.0):
    """-> (bpm rounded to 0.5, confidence 0..1) or (None, 0) when the clip is too short / silent."""
    env, fps = onset_envelope(audio, sr)
    if env is None:
        return None, 0.0
    env = env - env.mean()
    n = len(env)
    f = np.fft.rfft(env, 2 * n)
    acf = np.fft.irfft(f * np.conj(f))[:n]
    acf /= acf[0] + 1e-9
    bpms = np.arange(lo, hi + 0.01, 0.25)
    lags = 60.0 * fps / bpms

    def at(l):                                             # linear interpolation of the ACF
        i = np.floor(l).astype(int)
        w = l - i
        ok = i + 1 < n
        out = np.zeros_like(l)
        out[ok] = acf[i[ok]] * (1 - w[ok]) + acf[i[ok] + 1] * w[ok]
        return out
    # beat period plus its multiples (2x, 4x beats = bar) and the half period (off-beats) support the tempo
    score = at(lags) + 0.5 * at(2 * lags) + 0.25 * at(4 * lags) + 0.3 * at(lags / 2)
    prior = np.exp(-0.5 * (np.log2(bpms / 125.0) / 0.6) ** 2)   # dance music sits around 125
    s = score * (0.5 + 0.5 * prior)
    k = int(np.argmax(s))
    conf = float((s[k] - np.median(s)) / (abs(s[k]) + 1e-9))
    return round(float(bpms[k]) * 2) / 2, max(0.0, min(1.0, conf))
