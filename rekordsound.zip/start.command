#!/usr/bin/env bash
# Start rekordsound on macOS:   bash start.command   (or double-click it in Finder after: chmod +x start.command)
cd "$(dirname "$0")"
if lsof -nP -iTCP:7870 -sTCP:LISTEN >/dev/null 2>&1; then
  open http://127.0.0.1:7870/                      # already running: just open the page
  exit 0
fi
exec .venv/bin/python app.py                        # opens the browser itself; add --lan to reach it from other devices
