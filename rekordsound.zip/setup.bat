@echo off
rem rekordsound on Windows: double-click this file. First time it installs what is missing (a few minutes), then it starts the app.
rem Safe to run again. "setup.bat nostart" installs without starting.
setlocal
cd /d "%~dp0"
title rekordsound setup

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import torch, fastapi, transformers" >nul 2>&1
  if not errorlevel 1 goto ready
)

echo.
echo First start: installing what rekordsound needs (Python, ffmpeg, Node.js and the analysis libraries).
echo This takes a few minutes and downloads 1-3 GB. You can leave it running.
echo.

where winget >nul 2>&1
if errorlevel 1 (
  echo winget is missing. It comes with Windows 10 and 11 through the "App Installer" from the Microsoft Store.
  echo Update "App Installer" there, or install Python 3.12, ffmpeg and Node.js by hand, then run this again.
  goto fail
)

call :need ffmpeg Gyan.FFmpeg
call :need node OpenJS.NodeJS.LTS

set "PYCMD="
call :findpy
if defined PYCMD goto havepy
echo Installing Python 3.12 ...
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
call :refreshpath
call :findpy
if not defined PYCMD (
  echo Python was installed but this window cannot see it yet. Close this window and double-click setup.bat again.
  goto fail
)
:havepy
echo Using Python: %PYCMD%

%PYCMD% -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto fail

rem NVIDIA graphics card -> GPU build of PyTorch (about 2.5 GB); otherwise the CPU build.
set "TORCHIDX="
nvidia-smi >nul 2>&1
if not errorlevel 1 set "TORCHIDX=--index-url https://download.pytorch.org/whl/cu124"
if defined TORCHIDX (echo NVIDIA GPU found: installing the GPU build of PyTorch.) else (echo No NVIDIA GPU found: installing the CPU build of PyTorch. Analysis will be slow.)
".venv\Scripts\python.exe" -m pip install torch==2.6.0 torchaudio==2.6.0 %TORCHIDX%
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -c "import torch; print('GPU (CUDA) available:', torch.cuda.is_available())"

:ready
rem Desktop and Start-menu shortcuts with the app icon (rewritten on each run, so a moved folder is fixed too)
powershell -NoProfile -Command "foreach($d in 'Desktop','Programs'){$p=[Environment]::GetFolderPath($d)+'\rekordsound.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.IconLocation='%~dp0assets\rekordsound.ico'; $s.Description='Start rekordsound'; $s.Save()}; Write-Host 'Added rekordsound to the Desktop and the Start menu.'" 2>nul
if /i "%~1"=="nostart" (
  echo Ready. Start the app with start.bat.
  exit /b 0
)
call "%~dp0start.bat"
exit /b 0

:fail
echo.
echo Setup did not finish. The messages above say why; send them to whoever gave you this app.
pause
exit /b 1

rem ---- helpers ----
:need
where %1 >nul 2>&1
if not errorlevel 1 exit /b 0
echo Installing %1 ...
winget install -e --id %2 --accept-package-agreements --accept-source-agreements
call :refreshpath
exit /b 0

:findpy
set "PYCMD="
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3.12"
if defined PYCMD exit /b 0
py -3.11 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3.11"
if defined PYCMD exit /b 0
py -3.13 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3.13"
if defined PYCMD exit /b 0
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set PYCMD="%LocalAppData%\Programs\Python\Python312\python.exe"
exit /b 0

:refreshpath
rem programs installed a moment ago are only on the PATH of NEW windows: read the PATH from the registry
set "SYSPATH="
set "USRPATH="
for /f "skip=2 tokens=2,*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYSPATH=%%b"
for /f "skip=2 tokens=2,*" %%a in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USRPATH=%%b"
set "PATH=%PATH%;%SYSPATH%;%USRPATH%"
exit /b 0
