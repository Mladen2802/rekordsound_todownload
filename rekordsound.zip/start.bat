@echo off
cd /d "%~dp0"
netstat -ano | findstr ":7870 " | findstr LISTENING >nul
if errorlevel 1 start "rekordsound server" /min .venv\Scripts\python.exe app.py --no-browser
timeout /t 8 /nobreak >nul
start http://127.0.0.1:7870/
