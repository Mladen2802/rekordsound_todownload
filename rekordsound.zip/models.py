"""Audio decoding + CLAP / MERT embedders (ported from aroundsound common.py)."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")      # Apple GPU: run the odd unsupported op on the CPU instead of failing

SR = 48000            # CLAP expects 48 kHz mono
CLIP_SEC = 10         # CLAP looks at 10 s windows
MAX_CLIPS = 8         # clips sampled per track
# note: "laion/larger_clap_music" on the HF hub produces collapsed (useless) embeddings
CLAP_ID = "laion/larger_clap_music_and_speech"
CLAP_DIM = 512

MERT_ID = "m-a-p/MERT-v1-95M"
MERT_REV = "12af15fef9d0ac838c3f475bfbbf26d2060dd4f5"   # pinned: remote code reviewed at this revision
MERT_SR = 24000
MERT_SEC = 5                                             # MERT was trained on 5 s inputs
MERT_DIM = 768

_deno = shutil.which("deno") or str(Path.home() / ".local" / "bin" / "deno")      # VPS: Node 18 is too old for yt-dlp
JS_RUNTIME = f"deno:{_deno}" if os.path.exists(_deno) else "node"
YTDLP = [sys.executable, "-m", "yt_dlp", "--js-runtimes", JS_RUNTIME, "--quiet", "--no-warnings"]
COOKIES = Path(__file__).parent / "data" / "youtube-cookies.txt"   # optional: Netscape cookies.txt, for the VPS (YouTube bot check)


# ---------------------------------------------------------------- audio
def decode(path) -> np.ndarray:
    """Any audio/video file -> float32 mono 48 kHz."""
    out = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-i", str(path), "-vn", "-ac", "1",
                          "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(out, np.float32)


def download_audio(url: str, with_title=False):
    """Download best audio (YouTube, Vocaroo, ...) to a temp dir, decode, delete."""
    with tempfile.TemporaryDirectory() as tmp:
        r = subprocess.run(YTDLP + (["--cookies", str(COOKIES)] if COOKIES.exists() else []) + ["-f", "bestaudio/best", "-o", f"{tmp}/a.%(ext)s",
                                    "-O", "%(title)s", "--no-simulate", "--no-playlist", url],
                           check=True, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})   # Windows: titles with – etc.
        f = next(Path(tmp).iterdir())
        audio = decode(f)
        return (audio, r.stdout.strip()) if with_title else audio


def pick_clips(audio: np.ndarray):
    """Sample up to MAX_CLIPS 10 s windows spread over 8-92 % of the track (skipping intro/outro)."""
    n = CLIP_SEC * SR
    total = len(audio)
    if total <= n:
        return [audio], [0.0]
    lo, hi = int(total * 0.08), int(total * 0.92) - n
    if hi <= lo:
        lo, hi = 0, total - n
    k = max(1, min(MAX_CLIPS, (hi - lo) // n + 1))
    starts = np.linspace(lo, hi, k).astype(int)
    return [audio[s:s + n] for s in starts], [round(float(s) / SR, 1) for s in starts]


def standardize(x, mu, sd):
    """Raw MERT vector(s) -> library-standardized unit vector(s)."""
    z = (x - mu) / sd
    return z / np.linalg.norm(z, axis=-1, keepdims=True)


# ---------------------------------------------------------------- models
def pick_device():
    """NVIDIA GPU (cuda) > Apple GPU (mps) > cpu. Override with REKORDSOUND_DEVICE=cpu|cuda|mps."""
    import torch
    want = os.environ.get("REKORDSOUND_DEVICE")
    if want:
        return want
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def to_device(inp, device):
    """Move a dict of tensors; floats go as float32 (the Apple GPU has no float64)."""
    import torch
    return {k: v.to(device, torch.float32) if v.is_floating_point() else v.to(device) for k, v in inp.items()}


class Embedder:
    """CLAP: overall vibe / genre / mood; also embeds text."""

    def __init__(self):
        import torch
        from transformers import ClapModel, ClapProcessor
        self.torch = torch
        self.device = pick_device()
        self.model = ClapModel.from_pretrained(CLAP_ID).to(self.device).eval()
        if self.device == "cuda":
            self.model = self.model.half()
        self.proc = ClapProcessor.from_pretrained(CLAP_ID)

    def _norm(self, x):
        if not hasattr(x, "float"):          # transformers v5 returns an output object
            x = x.pooler_output
        x = x.float().cpu().numpy()
        return x / np.linalg.norm(x, axis=1, keepdims=True)

    def audio(self, clips):
        """List of 48 kHz arrays -> (n, 512) unit vectors."""
        inp = self.proc(audio=clips, sampling_rate=SR, return_tensors="pt")
        inp = to_device(inp, self.device)
        if self.device == "cuda":
            inp = {k: v.half() if v.is_floating_point() else v for k, v in inp.items()}
        with self.torch.no_grad():
            return self._norm(self.model.get_audio_features(**inp))

    def text(self, query: str):
        inp = self.proc(text=[query], return_tensors="pt", padding=True)
        inp = to_device(inp, self.device)
        with self.torch.no_grad():
            return self._norm(self.model.get_text_features(**inp))[0]

    def clips(self, clips):
        """Pre-cut clips -> (mean unit vector, clip matrix)."""
        C = self.audio(clips)
        m = C.mean(0)
        return m / np.linalg.norm(m), C


class MertEmbedder:
    """MERT music model: harmony / melody / groove / timbre. Returns *raw* vectors; they only become
    useful for similarity after standardize() with library statistics (see db.load_index)."""

    def __init__(self):
        import torch
        import torchaudio
        from transformers import AutoModel, Wav2Vec2FeatureExtractor
        self.torch, self.ta = torch, torchaudio
        self.device = pick_device()
        self.model = AutoModel.from_pretrained(MERT_ID, revision=MERT_REV, trust_remote_code=True).to(self.device).eval()
        if self.device == "cuda":
            self.model = self.model.half()
        self.proc = Wav2Vec2FeatureExtractor.from_pretrained(MERT_ID, revision=MERT_REV, trust_remote_code=True)
        # transformers v5 ignores output_hidden_states in MERT's remote code -> capture layers with hooks
        self._layers = []
        for layer in self.model.encoder.layers:
            layer.register_forward_hook(lambda m, i, o: self._layers.append(o[0] if isinstance(o, tuple) else o))

    def audio(self, clips48):
        """List of 48 kHz clips -> (n, 768) raw vectors (middle 5 s of each clip, all layers averaged)."""
        n = MERT_SEC * SR
        mids = [c[max(0, (len(c) - n) // 2):][:n] for c in clips48]
        L = max(len(c) for c in mids)
        x = np.stack([np.pad(c, (0, L - len(c))) for c in mids])
        x = self.ta.functional.resample(self.torch.from_numpy(x), SR, MERT_SR).numpy()
        inp = self.proc(list(x), sampling_rate=MERT_SR, return_tensors="pt")["input_values"].float().to(self.device)
        if self.device == "cuda":
            inp = inp.half()
        self._layers.clear()
        with self.torch.no_grad():
            self.model(inp)
        hs = self.torch.stack(self._layers)                 # layers, clips, time, dim
        self._layers.clear()
        return hs.float().mean(2).mean(0).cpu().numpy()

    def clips(self, clips):
        """Pre-cut clips -> (mean raw vector, raw clip matrix)."""
        C = self.audio(clips)
        return C.mean(0), C


EFFNET_FILE = "discogs-effnet-bsdynamic-1"
EFFNET_URL = "https://essentia.upf.edu/models/feature-extractors/discogs-effnet/"
EFFNET_SHA256 = "a280825b334797cf677939db8cd5762c0392aedd0ca6415dbc1cd083f045e43c"
EFFNET_SR = 16000
EFFNET_DIM = 1280
N_STYLES = 400


def slaney_mel(sr, n_fft, n_mels, fmin, fmax):
    """Slaney-style triangular mel filterbank with area normalisation (= librosa norm='slaney',
    Essentia warpingFormula='slaneyMel', normalize='unit_tri'). -> (n_mels, n_fft // 2 + 1)."""
    f_sp, min_log_hz = 200.0 / 3, 1000.0
    min_log_mel, logstep = min_log_hz / f_sp, np.log(6.4) / 27.0

    def hz2mel(f):
        f = np.asarray(f, float)
        return np.where(f >= min_log_hz, min_log_mel + np.log(np.maximum(f, 1e-10) / min_log_hz) / logstep, f / f_sp)

    def mel2hz(m):
        m = np.asarray(m, float)
        return np.where(m >= min_log_mel, min_log_hz * np.exp(logstep * (m - min_log_mel)), f_sp * m)

    freqs = np.linspace(0, sr / 2, n_fft // 2 + 1)
    pts = mel2hz(np.linspace(hz2mel(fmin), hz2mel(fmax), n_mels + 2))
    fd, ramps = np.diff(pts), pts[:, None] - freqs[None, :]
    W = np.maximum(0, np.minimum(-ramps[:-2] / fd[:-1, None], ramps[2:] / fd[1:, None]))
    W *= (2.0 / (pts[2:] - pts[:-2]))[:, None]
    return W.astype(np.float32)


def _effnet_files():
    """Download the ONNX model + metadata once to data/models/ (weights: CC BY-NC-SA 4.0, MTG/UPF)."""
    import hashlib
    import urllib.request
    d = Path(__file__).resolve().parent / "data" / "models"
    d.mkdir(parents=True, exist_ok=True)
    for ext in (".onnx", ".json"):
        p = d / (EFFNET_FILE + ext)
        if not p.exists():
            urllib.request.urlretrieve(EFFNET_URL + EFFNET_FILE + ext, p)
    onnx = d / (EFFNET_FILE + ".onnx")
    if hashlib.sha256(onnx.read_bytes()).hexdigest() != EFFNET_SHA256:
        raise RuntimeError(f"{onnx} has an unexpected checksum; delete it to re-download")
    return onnx, d / (EFFNET_FILE + ".json")


class EffnetEmbedder:
    """Discogs-EffNet (Essentia / MTG): the model cosine.club uses. Style-aware 1280-d embeddings plus
    probabilities for 400 Discogs styles. Runs as ONNX, with Essentia's TensorflowInputMusiCNN mel front-end
    re-implemented in numpy (16 kHz, 512/256 frames, 96 Slaney mel bands, log10(1 + 10000 x), 128-frame patches)."""

    PATCH, PATCH_HOP = 128, 62

    def __init__(self, power=True, threads=None):
        # power=True + Slaney area-normalised mel + raw (un-normalised) Hann window gave by far the most sensible
        # style predictions on the user's tagged tracks (variants compared 2026-11-06).
        import json
        import onnxruntime as ort
        import torch
        import torchaudio
        self.torch, self.ta = torch, torchaudio
        onnx, meta = _effnet_files()
        self.styles = json.loads(meta.read_text(encoding="utf-8", errors="replace"))["classes"]
        so = ort.SessionOptions()
        if threads:
            so.intra_op_num_threads = threads
        self.sess = ort.InferenceSession(str(onnx), so, providers=["CPUExecutionProvider"])
        self.inp = self.sess.get_inputs()[0].name
        self.outs = [o.name for o in self.sess.get_outputs()]          # [activations (400), embeddings (1280)]
        self.mel = slaney_mel(EFFNET_SR, 512, 96, 0, 8000)                 # (96, 257)
        self.win = np.hanning(512).astype(np.float32)
        self.power = power

    def melspec(self, y16):
        """16 kHz mono -> (frames, 96) log-compressed mel bands."""
        if len(y16) < 512:
            y16 = np.pad(y16, (0, 512 - len(y16)))
        n = 1 + (len(y16) - 512) // 256
        idx = np.arange(512)[None, :] + 256 * np.arange(n)[:, None]
        spec = np.abs(np.fft.rfft(y16[idx] * self.win, axis=1)).astype(np.float32)   # (frames, 257)
        if self.power:
            spec = spec ** 2
        return np.log10(1 + 10000 * (spec @ self.mel.T))

    def patches(self, mel):
        if len(mel) < self.PATCH:
            mel = np.pad(mel, ((0, self.PATCH - len(mel)), (0, 0)))
        starts = range(0, len(mel) - self.PATCH + 1, self.PATCH_HOP)
        return np.stack([mel[s:s + self.PATCH] for s in starts]).astype(np.float32)

    def clips(self, clips48):
        """List of 48 kHz clips -> (unit mean vector, (n, 1280) unit clip matrix, (400,) mean style probabilities)."""
        P, owner = [], []
        for ci, c in enumerate(clips48):
            y16 = self.ta.functional.resample(self.torch.from_numpy(np.ascontiguousarray(c)), SR, EFFNET_SR).numpy()
            p = self.patches(self.melspec(y16))
            P.append(p)
            owner += [ci] * len(p)
        act, emb = self.sess.run(self.outs, {self.inp: np.concatenate(P)})
        owner = np.array(owner)
        C = np.stack([emb[owner == ci].mean(0) for ci in range(len(clips48))])
        C /= np.linalg.norm(C, axis=1, keepdims=True) + 1e-9
        m = C.mean(0)
        return m / (np.linalg.norm(m) + 1e-9), C, act.mean(0)


def embed_track(clap: Embedder | None, mert: MertEmbedder | None, audio, effnet: EffnetEmbedder | None = None):
    """Decoded 48 kHz track -> dict with clip_starts and, per model given, its vectors."""
    clips, starts = pick_clips(audio)
    r = dict(clip_starts=starts)
    if clap:
        r["clap"], r["clap_clips"] = clap.clips(clips)
    if mert:
        r["mert"], r["mert_clips"] = mert.clips(clips)
    if effnet:
        r["effnet"], r["effnet_clips"], r["styles"] = effnet.clips(clips)
    return r
