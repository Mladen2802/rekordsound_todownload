"""Copy your local results to the online (read-only, search-only) rekordsound server. Analysis always happens on this computer.

    python publish.py --setup user@your-server /path/to/rekordsound/data    # once: remember where to upload (data/publish.json)
    python publish.py                         # build a slim copy of the data, upload it over SSH, swap it in on the server
    python publish.py --dry-run               # build + show what would be uploaded, upload nothing
    python publish.py --build-only            # only write the slim files to data/publish/ (copy them yourself)

What goes online: the search vectors, energy values, your playlists and the collection XML. What stays here: the audio files,
cover art, the per-clip model outputs the website never uses, logs and the failed / backup tables. Needs `ssh` and `scp`
(built into Windows 10+ and macOS) and key-based login to the server. The server picks the new data up by itself within
about a minute. Run it again after every analysis or Rekordbox export.
"""
import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path

import db
import library

OUT = db.ROOT / "data" / "publish"
CONFIG = db.ROOT / "data" / "publish.json"
HOST_RE = re.compile(r"^[\w.-]+@[\w.-]+$|^[\w.-]+$")        # user@host, or a Host alias from ~/.ssh/config
DIR_RE = re.compile(r"^[\w./~-]+$")                         # no spaces or shell characters: used unquoted in remote commands


def build_slim(dest: Path):
    """Write dest: the tables the website needs, from the local library.db (a consistent snapshot, one single file)."""
    for suffix in ("", "-wal", "-shm"):
        Path(str(dest) + suffix).unlink(missing_ok=True)
    db.connect().close()                                    # make sure the local schema is up to date
    con = db.connect(dest)                                  # same schema as the app expects
    con.execute("PRAGMA journal_mode=DELETE")               # one file, no -wal to ship
    con.execute("ATTACH DATABASE ? AS src", (str(db.DB_PATH),))
    cols = {
        "audio": "key, path, mtime, size, duration, clap, clap_clips, mert, clip_starts, effnet, styles, analyzed_at",
        "energy": "key, mtime, size, feats, score",
        "genre_pred": "key, genre, second, confidence",
        "playlist": "id, name, source, created, updated",
        "playlist_track": "playlist_id, pos, key",
    }
    for table, c in cols.items():
        con.execute(f"INSERT INTO main.{table} ({c}) SELECT {c} FROM src.{table}")
    con.commit()
    counts = {t: con.execute(f"SELECT COUNT(*) FROM main.{t}").fetchone()[0] for t in cols}
    con.execute("DETACH DATABASE src")
    con.close()
    for suffix in ("-wal", "-shm"):
        Path(str(dest) + suffix).unlink(missing_ok=True)
    return counts


def load_config():
    if not CONFIG.exists():
        sys.exit("Not set up yet. Run once:  python publish.py --setup user@your-server /path/to/rekordsound/data")
    return json.loads(CONFIG.read_text(encoding="utf-8"))


def check(host, remote_dir):
    if not HOST_RE.match(host):
        sys.exit(f"Odd-looking host: {host!r} (use user@host or a Host name from your ~/.ssh/config)")
    if not DIR_RE.match(remote_dir):
        sys.exit(f"Remote folder {remote_dir!r}: use letters, digits and / . _ ~ - only (no spaces)")


def run(cmd, dry=False):
    print("$ " + " ".join(cmd), flush=True)
    if not dry:
        subprocess.run(cmd, check=True, cwd=db.ROOT)       # relative file names below: no 'C:' for scp to mistake for a host


def main():
    ap = argparse.ArgumentParser(description="Copy local results to the online read-only server.")
    ap.add_argument("--setup", nargs=2, metavar=("HOST", "REMOTE_DATA_DIR"), help="save where to upload, e.g. me@myserver /srv/rekordsound/data")
    ap.add_argument("--port", type=int, help="SSH port (saved with --setup)")
    ap.add_argument("--build-only", action="store_true", help="only write the files to data/publish/")
    ap.add_argument("--dry-run", action="store_true", help="build, show the upload commands, upload nothing")
    ap.add_argument("--xml", default=str(library.DEFAULT_XML), help="collection XML to publish")
    a = ap.parse_args()

    if a.setup:
        check(*a.setup)
        CONFIG.parent.mkdir(exist_ok=True)
        CONFIG.write_text(json.dumps(dict(host=a.setup[0], dir=a.setup[1].rstrip("/"), port=a.port or 22), indent=2), encoding="utf-8")
        print(f"saved {CONFIG}. Test it with:  python publish.py --dry-run")
        return

    xml = Path(a.xml)
    if not xml.exists():
        sys.exit(f"Collection XML not found: {xml}")
    OUT.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    print("building slim copy of the database ...", flush=True)
    counts = build_slim(OUT / "library.db")
    size = (OUT / "library.db").stat().st_size
    print(f"  {counts['audio']} analysed tracks, {counts['playlist']} playlists, {counts['energy']} energy values: "
          f"{size / 1e6:.0f} MB in {time.time() - t0:.0f} s")
    (OUT / "rekordbox.xml").write_bytes(xml.read_bytes())
    if a.build_only:
        print(f"files are in {OUT}")
        return

    cfg = load_config()
    host, rdir, port = cfg["host"], cfg["dir"], str(cfg.get("port", 22))
    check(host, rdir)
    ssh, scp = ["ssh", "-p", port, host], ["scp", "-P", port]
    inc = f"{rdir}/.incoming"
    run(ssh + [f"mkdir -p {inc}"], a.dry_run)
    run(scp + ["data/publish/library.db", "data/publish/rekordbox.xml", f"{host}:{inc}/"], a.dry_run)
    # swap in. Stale -wal / -shm files from the old database must go, or SQLite would apply them to the new file.
    run(ssh + [f"cd {rdir} && rm -f library.db-wal library.db-shm && mv -f .incoming/library.db library.db "
               f"&& mv -f .incoming/rekordbox.xml rekordbox.xml && ls -l library.db rekordbox.xml"], a.dry_run)
    if cfg.get("restart"):
        run(ssh + [cfg["restart"]], a.dry_run)
    print("dry run only, nothing was uploaded" if a.dry_run else "published. The site picks up the new data within about a minute.")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
