# rekordsound

Find tracks in your own Rekordbox library that **sound similar** — for set prep and "what to play next".
It reads your Rekordbox XML export (read-only), analyses the audio files once, and then searches by sound,
filtered by the BPM, key, genre and playlists you already have in Rekordbox.

## Features

- **Search by** a library track, an uploaded file, a **microphone recording** (hear an unknown track in a club),
  a YouTube / Vocaroo / Bandcamp link, or a text description ("dark rolling techno").
- **Three audio models**, selectable as "Match by": *Style* (discogs-effnet), *Vibe* (CLAP), *Musical* (MERT), or *Blend*.
- **Filters:** BPM range or ±% of the source (incl. half/double time), harmonic key (Camelot: same / compatible),
  genre (with excludes), year, rating, playlist, minimum match %. "Next track" preset = similar + mixable BPM + compatible key.
- **BPM detection** for recordings and links, so the BPM filters work on them too.
- **Energy 1-10** (estimate): measured from the audio (loudness, rhythm density, brightness, low end, tempo) and ranked
  against your own library, so it is relative to it and not Mixed In Key's number. Shown on every row; filter by min / max or
  "± levels of the source". Run `python energy.py` once (about 1 s per track, resumable; new tracks get it from `analyze.py`).
- Shows the **best-matching part** of every result and plays it (AIFF is served as WAV on the fly, with seeking).
- **Export** results or your crate as a Rekordbox XML playlist or M3U8.
- **Playlists tab:** create, rename, delete and reorder (drag or ▲▼) your own playlists, add tracks from any list with the
  playlist button, save the crate as a playlist, and copy a Rekordbox playlist to edit it. These are copies stored in
  `data/library.db` (matched by file path, so they survive re-exports); Rekordbox is never changed. Export one as M3U8 or
  Rekordbox XML to bring it back. **Suggest similar** averages the open playlist's tracks into one query and lists library
  tracks that sound like the playlist as a whole (honouring your Filter settings), each with a one-click Add.
- **Import tab:** choose a freshly exported collection XML and get a report first: new and removed tracks, added / removed /
  changed playlists, and which tracks are not analysed yet (file found vs not found). **Apply import** swaps in the new
  XML (the old one is kept as `data/rekordbox.<timestamp>.xml`), and **Analyse** runs `analyze.py` with a progress bar.
  Analysis uses the GPU, so avoid heavy searches meanwhile on a 4 GB card.
- Optional **genre predictor** (`genres.py`) that can write a DJ genre to file tags (dry run first, undo supported).
- **Server mode** for a VPS without audio files (no player; YouTube search links instead), plus a Tampermonkey
  userscript that shows similar library tracks on YouTube pages.

rekordsound never writes to Rekordbox or its database.

## Requirements

- Windows, macOS or Linux, Python 3.11+, `ffmpeg` on PATH, Node.js (for YouTube downloads via yt-dlp; Deno also works).
- A GPU is recommended for analysis: NVIDIA (~4 s/track on a 4 GB laptop GPU) or an Apple Silicon Mac (uses the Apple GPU
  automatically); CPU works, slower. Set `REKORDSOUND_DEVICE=cpu` to force the CPU.

## Install

**One click:** Windows: double-click `setup.bat`. macOS: paste one line into Terminal (below). Both install what is missing, then
start the app; run them again any time, they skip what is already done. Windows uses `winget` (Python, ffmpeg, Node.js) and picks
the GPU build of PyTorch when it finds an NVIDIA card. macOS installs Homebrew first, after asking you.

macOS, the line to paste (Terminal is in Applications > Utilities):

```
curl -fsSL https://raw.githubusercontent.com/Mladen2802/rekordsound_todownload/main/get-rekordsound.sh | bash
```

It downloads the app into `~/rekordsound` and starts the install. It also adds **rekordsound.app** (with an icon) to `~/Applications`, so the app is in Launchpad and Spotlight,
and a copy on the Desktop; drag it to the Dock to keep it there. Running it again updates the program and keeps your data.
macOS blocks double-clicking files downloaded in a browser ("damaged and can't be opened"), but `curl` downloads are not blocked.
If you already have the folder, `xattr -cr . && bash "Install and Start.command"` inside it does the same job.

*Sharing it (for the person who owns the app):* upload `rekordsound.zip` (`git archive --format=zip -o rekordsound.zip HEAD`) and
`get-rekordsound.sh` to the same place, e.g. a GitHub release or your server, set `ZIP_URL` at the top of `get-rekordsound.sh` to
the zip's direct link, and give people the `curl` line with the script's link.

By hand:

```
python -m venv .venv
.venv\Scripts\activate            # Linux: source .venv/bin/activate
pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu124   # CPU: .../whl/cpu
pip install -r requirements.txt
```

Model weights (CLAP, MERT, discogs-effnet) are downloaded on first use.

### macOS

Apple Silicon (M1 or newer) is recommended; an Intel Mac works but analyses on the CPU only.
Use the Terminal line under "One click" above. If the zip lost the executable flag, run
`chmod +x *.command *.sh` once. Or by hand, in Terminal inside the rekordsound folder (needs [Homebrew](https://brew.sh)):

```
bash setup-mac.sh        # installs ffmpeg, node, Python 3.12, a .venv and the packages (once, a few minutes)
bash start.command       # starts the app and opens http://127.0.0.1:7870
```

Then use the **Import** tab: choose your exported Rekordbox XML, press **Apply import**, then **Analyse**.
Analysis is resumable, so it can run overnight and be stopped any time. Check the speed first with
`.venv/bin/python analyze.py --limit 20` (it prints seconds per track). The first run downloads about 1 GB of models.
Paths like `/Users/you/Music/...` and `/Volumes/Drive/...` in the XML are handled; the analysis database is specific to the
computer it was made on (it stores file paths), so each machine analyses its own library. Everything stays on that computer.

## Uninstall

rekordsound lives in one folder and never touches Rekordbox or your music files. To remove it:

1. Close the app (close its Terminal window on macOS, or the minimized "rekordsound server" window on Windows).
2. Delete the **launchers**: macOS `~/Applications/rekordsound.app` and the `rekordsound` item on the Desktop (remove it from the Dock
   too); Windows the `rekordsound` shortcuts on the Desktop and in the Start menu.
3. Delete the **rekordsound folder** (macOS: `~/rekordsound` if it was installed with the one-line command). This removes the app, its
   Python packages (`.venv`) and your analysis database and downloaded effnet model (`data/`). Copy `data/library.db` somewhere first
   if you want to keep the analysis.
4. Optional, frees about 1.5 GB: the CLAP and MERT models are cached outside the folder. Delete the folders starting with
   `models--laion--clap` and `models--m-a-p--MERT` inside `~/.cache/huggingface/hub` (Windows: `%USERPROFILE%\.cache\huggingface\hub`).
5. Optional: the installers also added general tools that other programs may use, so remove them only if you do not need them:
   macOS `brew uninstall ffmpeg node python@3.12`; Windows Settings > Apps > Python 3.12, FFmpeg, Node.js.

## Use

1. In Rekordbox: **File → Export Collection in xml format**. Either save it as `data/rekordbox.xml`, or start the app and use the
   **Import** tab (it opens there by itself the first time).
2. Check the library: `python library.py` (track count, playlists, missing files).
3. Analyse the audio (resumable, safe to stop with Ctrl+C, re-run any time; changed files are re-analysed):
   `python analyze.py` (`--limit N` for a test run). Results go to `data/library.db`.
4. Start the app: `python app.py` → http://127.0.0.1:7870 (or `setup.bat` / `start.bat` on Windows, `Install and Start.command` on macOS).

## Other tools

| Command | Purpose |
|---|---|
| `python genres.py eval` / `predict` / `write` / `undo` | Predict a DJ genre from the audio; optionally write it to file tags (original kept, undoable). |
| `python energy.py` | Measures the energy of every track (`--limit N` to test, `--recalibrate` to re-score from stored features, `--show N` to print a sample). |
| `python tidy.py` | Finds **audio files** that are not in your Rekordbox collection and moves them into one folder for review. See "Tidying" below. |
| `rekordsound.user.js` | Tampermonkey script: "Find similar in my library" button on YouTube video pages. Uses the local app if it is running, otherwise the server (asks for the login once). Edit the server URL at the top. |

## Tidying: audio files that are not in the collection

`tidy.py` finds audio files that are not part of your Rekordbox collection and moves them into one folder, so you can
review them and delete them yourself. **Only audio files are ever touched** (`.aif .aiff .wav .mp3 .flac .m4a .aac .ogg
.opus .wma .alac .mp4 .m4b`); images, text, torrents, logs and system files are left alone. Nothing is deleted, it is a
dry run unless you pass `--apply`, and every move is logged so `--undo` puts it all back.

```
python tidy.py                                  # dry run on the default folder (edit DEFAULT_ROOT in the file)
python tidy.py --root D:\Music --root E:\       # look wider: several folders or whole drives, when you don't know where they are
python tidy.py --apply                          # move the files (a rename on the same drive, no extra space needed)
python tidy.py --undo                           # restore the last moves from the log
```

- Files go to `<folder>_not_in_collection` next to each scanned folder (`X:\_not_in_collection` for a whole drive),
  keeping their folder structure; `--dest` chooses another folder on the same drive.
- System and program folders (Windows, Program Files, AppData, ...) are skipped, as are files changed in the last 6 hours
  and `PioneerDJ` folders (`--include-pioneer` to include them).
- Matching is by file path: a copy of a collection track kept in another folder counts as "not in the collection".
- Re-export the collection from Rekordbox first and close Rekordbox before `--apply`; otherwise tracks added since the
  last export would look like strays.

## Using it from another device (Mac, phone, tablet)

Everything stays on the Windows PC (audio files, analysis, GPU); other devices just open the site in a browser.
Start with `start-lan.bat` (or `python app.py --lan`). The server window prints an address like `http://192.168.1.20:7870`;
open it on the other device while both are on the same network. Playback, cover art, playlists and import all work.

- Allow Python through the Windows firewall (private networks) when Windows asks the first time.
- There is **no login**: use it only on a network you trust, never on public Wi-Fi or forwarded through your router.
- Microphone recording needs HTTPS outside `localhost`, so on other devices use the upload button with a recording instead.
- The PC must be on, with the server running.

## Running on a server (read-only mirror, search only)

Analysis, playlists and the audio stay on your own computer. The server only searches the results you send it.

- Set `REKORDSOUND_NOPLAY=1` on the server (no audio there: hides the player, play buttons and cover art, disables `/api/audio`).
  This also makes the server **read-only**: playlists, import and analysis are disabled (HTTP 403, and hidden in the page).
  Searching still works: a library track, a YouTube / Bandcamp / Vocaroo link, a microphone recording, an uploaded file, a text
  description, and "Suggest similar" on a playlist. (`REKORDSOUND_READONLY=1` gives the read-only part alone, with audio.)
- First time only: copy `data/models/` to the server and run `python app.py` there behind an HTTPS reverse proxy with
  authentication. The app itself has **no login**, so never expose it unprotected.
- Sending your data: on your computer run `python publish.py --setup user@your-server /path/to/rekordsound/data` once (needs
  key-based SSH login), then `python publish.py` after every analysis or Rekordbox export. It uploads a slim copy of the
  database (about 40 % of its size: the search vectors, energy values, playlists, no per-clip extras) and the XML, swaps them in
  safely and the site picks them up within about a minute. `--dry-run` shows what it would do; `--build-only` just writes the
  files to `data/publish/`. Playlists you make locally are included, so they appear online too.
- HTTPS is required for microphone recording in browsers (except on `localhost`).
- YouTube blocks most datacenter IPs. Put a Netscape-format `data/youtube-cookies.txt` (from a throwaway account) next
  to the app to enable link search there; cookies expire every few weeks.

## Notes

- `data/` (database, XML export, logs, cookies, models) is git-ignored; it holds your library and credentials.
- The discogs-effnet weights are CC BY-NC-SA 4.0 (non-commercial); the other models have their own licences. Personal use.
- Background and design decisions: [PLAN.md](PLAN.md).
