@echo off
rem Like start.bat, but the site can also be opened from other devices on your network (the address is printed in the server window).
cd /d "%~dp0"
netstat -ano | findstr ":7870 " | findstr LISTENING >nul
if errorlevel 1 start "rekordsound server (LAN)" .venv\Scripts\python.exe app.py --no-browser --lan
timeout /t 8 /nobreak >nul
start http://127.0.0.1:7870/
