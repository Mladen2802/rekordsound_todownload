"""Serve an uncompressed AIFF/AIFC file to the browser as WAV, on the fly and with HTTP Range support.
Browsers (Chrome/Edge/Firefox) don't play AIFF, but AIFF is just big-endian PCM: swapping byte order
and prepending a WAV header is enough. No transcoding, no cache, instant seeking."""
import math
import re
import struct

import numpy as np
from fastapi import HTTPException
from fastapi.responses import Response, StreamingResponse

CHUNK = 1 << 20


def _ext80(b):
    """80-bit IEEE extended float (AIFF sample rate) -> float."""
    exp = ((b[0] & 0x7F) << 8) | b[1]
    mant = int.from_bytes(b[2:10], "big")
    if exp == 0 and mant == 0:
        return 0.0
    return math.ldexp(mant, exp - 16383 - 63) * (-1 if b[0] & 0x80 else 1)


def parse(path):
    """-> dict(channels, rate, bits, data_offset, data_len, swap) or None if not plain PCM AIFF."""
    with open(path, "rb") as f:
        head = f.read(12)
        if len(head) < 12 or head[:4] != b"FORM" or head[8:12] not in (b"AIFF", b"AIFC"):
            return None
        aifc, info = head[8:12] == b"AIFC", {}
        while True:
            h = f.read(8)
            if len(h) < 8:
                break
            cid, size = h[:4], struct.unpack(">I", h[4:])[0]
            start = f.tell()
            if cid == b"COMM":
                c = f.read(size)
                info.update(channels=struct.unpack(">h", c[0:2])[0], frames=struct.unpack(">I", c[2:6])[0],
                            bits=struct.unpack(">h", c[6:8])[0], rate=_ext80(c[8:18]))
                comp = c[18:22] if aifc and len(c) >= 22 else b"NONE"
                if comp not in (b"NONE", b"sowt", b"twos"):
                    return None
                info["swap"] = comp != b"sowt"
            elif cid == b"SSND":
                offset = struct.unpack(">I", f.read(4))[0]
                info.update(data_offset=start + 8 + offset, ssnd_len=size - 8 - offset)
            f.seek(start + size + (size & 1))
    if "channels" not in info or "data_offset" not in info or info["bits"] not in (8, 16, 24, 32):
        return None
    width = (info["bits"] + 7) // 8
    info["width"] = width
    info["data_len"] = min(info["ssnd_len"], info["frames"] * info["channels"] * width)
    return info


def wav_header(i):
    block = i["channels"] * i["width"]
    rate = int(round(i["rate"]))
    return (b"RIFF" + struct.pack("<I", 36 + i["data_len"]) + b"WAVEfmt " +
            struct.pack("<IHHIIHH", 16, 1, i["channels"], rate, rate * block, block, i["width"] * 8) +
            b"data" + struct.pack("<I", i["data_len"]))


def _convert(raw, i):
    w = i["width"]
    if w == 1:                                   # AIFF 8-bit is signed, WAV 8-bit is unsigned
        return (np.frombuffer(raw, np.uint8) ^ 0x80).tobytes()
    if not i["swap"]:
        return raw
    return np.frombuffer(raw, np.uint8).reshape(-1, w)[:, ::-1].tobytes()


def response(path, info, range_header):
    hdr = wav_header(info)
    total = len(hdr) + info["data_len"]
    start, end = 0, total - 1
    if range_header:
        m = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
        if not m or (not m.group(1) and not m.group(2)):
            raise HTTPException(416, "Bad range")
        if m.group(1):
            start = int(m.group(1))
            end = min(int(m.group(2)), total - 1) if m.group(2) else total - 1
        else:                                     # suffix range: last N bytes
            start = max(0, total - int(m.group(2)))
        if start >= total or start > end:
            return Response(status_code=416, headers={"Content-Range": f"bytes */{total}"})

    def body():
        pos, w = start, info["width"]
        if pos < len(hdr):
            out = hdr[pos:end + 1]
            pos += len(out)
            yield out
        with open(path, "rb") as f:
            while pos <= end:
                d0 = pos - len(hdr)                       # offset within PCM data
                a = d0 - d0 % w                           # align to whole samples
                n = min(CHUNK, info["data_len"] - a)
                n -= n % w
                if n <= 0:
                    break
                f.seek(info["data_offset"] + a)
                raw = f.read(n)
                if not raw:
                    break
                raw = raw[:len(raw) - len(raw) % w]
                piece = _convert(raw, info)[d0 - a:]
                piece = piece[:end + 1 - pos]
                if not piece:
                    break
                pos += len(piece)
                yield piece

    headers = {"Accept-Ranges": "bytes", "Content-Length": str(end - start + 1)}
    if range_header:
        headers["Content-Range"] = f"bytes {start}-{end}/{total}"
    return StreamingResponse(body(), status_code=206 if range_header else 200, media_type="audio/wav",
                             headers=headers)
