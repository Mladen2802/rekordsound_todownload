#!/usr/bin/env bash
# rekordsound on macOS: double-click this file. The first time it installs everything (a few minutes), after that it just starts the app.
# If macOS says it is "damaged" (it is not: it blocks files from the internet), open Terminal in this folder and run:
#   xattr -cr . && bash "Install and Start.command"
cd "$(dirname "$0")" || exit 1

pause_exit() { echo; read -n 1 -s -r -p "Press any key to close this window."; echo; exit "${1:-1}"; }

# Remove the "downloaded from the internet" flag from this folder so the other scripts do not trigger the same warning.
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x ./*.command ./*.sh 2>/dev/null

# Already running: just open the page.
if lsof -nP -iTCP:7870 -sTCP:LISTEN >/dev/null 2>&1; then
  open http://127.0.0.1:7870/
  exit 0
fi

if ! .venv/bin/python -c "import torch, fastapi, transformers" >/dev/null 2>&1; then
  echo "First start: installing what rekordsound needs (ffmpeg, Node, Python, the analysis models' libraries)."
  echo "This takes a few minutes and downloads about 1 GB. You can leave it running."
  echo

  # Homebrew: look in the usual places, offer to install it when missing.
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    [ -x "$b" ] && eval "$("$b" shellenv)" && break
  done
  if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew (the macOS package manager) is not installed. It is needed once, to install ffmpeg and Python."
    echo "It is installed with the official script from https://brew.sh and asks for your Mac password."
    read -r -p "Install Homebrew now? [y/N] " a
    case "$a" in
      [yY]*) /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || pause_exit 1 ;;
      *) echo "Cancelled. Install Homebrew from https://brew.sh, then double-click this file again."; pause_exit 1 ;;
    esac
    for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
      [ -x "$b" ] && eval "$("$b" shellenv)" && break
    done
    command -v brew >/dev/null 2>&1 || { echo "Homebrew was installed but is not on the PATH. Close this window and double-click again."; pause_exit 1; }
  fi

  bash ./setup-mac.sh || { echo; echo "Setup failed. The messages above say why; send them to whoever gave you this app."; pause_exit 1; }
fi

echo
echo "Starting rekordsound at http://127.0.0.1:7870 (leave this window open while you use it; close it to stop)."
exec .venv/bin/python app.py
