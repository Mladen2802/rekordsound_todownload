"""Find AUDIO files that are not in your Rekordbox collection and move them into one folder for review.

Only audio files are ever listed or moved (.aif .aiff .wav .mp3 .flac .m4a .aac .ogg .opus .wma .alac .mp4 .m4b);
images, text, torrents, logs, documents and system files are never touched. Nothing is ever deleted.

    python tidy.py                                   # dry run on the default folder: summary + data/tidy_plan.txt
    python tidy.py --root D:\\Music --root E:\\        # look wider (folders or whole drives) when you don't know where they are
    (macOS: python tidy.py --root ~/Music --root /Volumes/MyDrive)
    python tidy.py --apply                         # move the files (rename on the same drive), log to data/tidy_moved.log
    python tidy.py --undo                            # move everything back using the log

The collection comes from data/rekordbox.xml: re-export it from Rekordbox first (File > Export Collection in xml
format) and close Rekordbox before --apply, otherwise recently added tracks would be treated as "not in collection".
Matching is by file path: a copy of a collection track stored in another folder counts as "not in collection".
"""
import argparse
import os
import sys
import time
from collections import defaultdict
from pathlib import Path

import library

DEFAULT_ROOT = r"D:\Music" if os.name == "nt" else str(Path.home() / "Music")      # edit for your own library
XML = Path("data/rekordbox.xml")
PLAN = Path("data/tidy_plan.txt")
LOG = Path("data/tidy_moved.log")
AUDIO = {".aif", ".aiff", ".wav", ".mp3", ".flac", ".m4a", ".aac", ".ogg", ".opus", ".wma", ".alac", ".mp4", ".m4b"}
RECENT_SEC = 6 * 3600                 # skip files modified in the last 6 h (may still be downloading)
# folders never entered (case-insensitive names): system / program / tooling folders, so whole-drive scans are safe
SKIP_DIRS = {"windows", "program files", "program files (x86)", "programdata", "appdata", "$recycle.bin",
             "system volume information", ".git", "node_modules", ".venv"}
if sys.platform == "darwin":          # macOS system / app folders (only there: a Windows music folder may be called "Library")
    SKIP_DIRS |= {"library", "applications", "system", ".trashes", ".trash", ".spotlight-v100", ".fseventsd", "private", "cores"}


def default_dest(root: Path) -> Path:
    """Sibling folder <name>_not_in_collection, or X:\\_not_in_collection for a whole drive."""
    root = Path(root)
    if root.parent == root:
        return Path(root.drive + os.sep if root.drive else root) / "_not_in_collection"
    return root.with_name(root.name + "_not_in_collection")


def same_volume(a, b) -> bool:
    """True when a rename between the two paths stays on one drive / volume (b may not exist yet)."""
    def dev(p):
        p = Path(os.path.abspath(p))
        while not p.exists() and p.parent != p:
            p = p.parent
        return os.stat(p).st_dev
    return dev(a) == dev(b)


def _norm(p) -> str:
    return os.path.normcase(os.path.normpath(str(p)))


def scan(roots, dests, include_pioneer=False, extra_skip=()):
    """-> (collection size, to_move [(path, size, root index)], recent, pioneer, number of non-audio files left alone)"""
    tracks, _, _ = library.load(XML)
    keep = {library.path_key(t["path"]) for t in tracks.values()}
    skip = SKIP_DIRS | {s.lower() for s in extra_skip}
    dest_keys = {_norm(d) for d in dests}
    out, recent, pioneer, other = [], [], [], 0
    for ri, root in enumerate(roots):
        for r, dirs, files in os.walk(root, onerror=lambda e: None):
            dirs[:] = [d for d in dirs if d.lower() not in skip and _norm(Path(r, d)) not in dest_keys]
            for f in files:
                p = os.path.join(r, f)
                if os.path.splitext(f)[1].lower() not in AUDIO:      # ONLY audio files are ever candidates
                    other += 1
                    continue
                if library.path_key(p) in keep:
                    continue
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                item = (p, st.st_size, ri)
                if "pioneerdj" in p.lower().split(os.sep):
                    (out if include_pioneer else pioneer).append(item)
                elif time.time() - st.st_mtime < RECENT_SEC:
                    recent.append(item)
                else:
                    out.append(item)
    return len(keep), out, recent, pioneer, other


def target(p, root, dest) -> Path:
    return Path(dest) / Path(p).relative_to(root)


def apply(out, roots, dests):
    """Move the files (os.rename, same drive only), logging every move. Returns the number of files moved."""
    clashes = [p for p, _, ri in out if target(p, roots[ri], dests[ri]).exists()]
    if clashes:
        sys.exit(f"abort: {len(clashes)} targets already exist, e.g. {clashes[0]}")
    n = 0
    with open(LOG, "a", encoding="utf-8") as log:
        for p, _, ri in out:
            dest = target(p, roots[ri], dests[ri])
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.rename(p, dest)
            log.write(f"{p}\t{dest}\n")
            log.flush()
            n += 1
    return n


def undo():
    if not LOG.exists():
        sys.exit("no log")
    n = 0
    for ln in LOG.read_text(encoding="utf-8").splitlines()[::-1]:
        old, new = ln.split("\t")
        if os.path.exists(new) and not os.path.exists(old):
            os.makedirs(os.path.dirname(old), exist_ok=True)
            os.rename(new, old)
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description="Move AUDIO files that are not in the Rekordbox collection into one folder. "
                                             "Dry run unless --apply. Never deletes; non-audio files are never touched.")
    ap.add_argument("--root", action="append", help=f"folder or drive to scan (repeatable). Default: {DEFAULT_ROOT}")
    ap.add_argument("--dest", help="folder to move files to (default: <root>_not_in_collection next to each root; "
                                   "X:\\_not_in_collection for a whole drive). Must be on the same drive as the roots")
    ap.add_argument("--skip", action="append", default=[], help="extra folder name to skip (repeatable)")
    ap.add_argument("--apply", action="store_true", help="actually move the files")
    ap.add_argument("--undo", action="store_true", help="move everything back using the log")
    ap.add_argument("--include-pioneer", action="store_true", help="also move files inside PioneerDJ folders")
    a = ap.parse_args()

    if a.undo:
        print(f"restored {undo()} files")
        return

    roots = [Path(os.path.abspath(r)) for r in (a.root or [DEFAULT_ROOT])]
    for r in roots:
        if not r.is_dir():
            sys.exit(f"not a folder: {r}")
    dests = [Path(os.path.abspath(a.dest)) if a.dest else default_dest(r) for r in roots]
    for r, d in zip(roots, dests):
        if not same_volume(r, d):
            sys.exit(f"destination {d} is on another drive than {r}: that would copy and delete instead of rename. "
                     f"Choose a destination on the same drive.")

    nkeep, out, recent, pioneer, other = scan(roots, dests, a.include_pioneer, a.skip)
    xm = time.strftime("%Y-%m-%d", time.localtime(XML.stat().st_mtime))
    print(f"collection (XML of {xm}): {nkeep} entries")
    print("scanning: " + ", ".join(str(r) for r in roots))
    by = defaultdict(lambda: [0, 0])
    for p, s, ri in out:
        parts = Path(p).relative_to(roots[ri]).parts
        key = (parts[0] if len(parts) > 1 else "(root)") if len(roots) == 1 else f"{roots[ri]} {parts[0] if len(parts) > 1 else ''}".strip()
        by[key][0] += 1
        by[key][1] += s
    print(f"audio files to move: {len(out)} files, {sum(s for _, s, _ in out) / 1e9:.1f} GB")
    for k, (n, s) in sorted(by.items(), key=lambda kv: -kv[1][1])[:15]:
        print(f"  {s / 1e9:7.1f} GB  {n:6d} files  {k}")
    print(f"left alone, not audio: {other} files (never touched)")
    print(f"skipped, modified in the last 6 h: {len(recent)}")
    print(f"skipped, inside PioneerDJ folders: {len(pioneer)} files, {sum(s for _, s, _ in pioneer) / 1e9:.1f} GB "
          f"(use --include-pioneer to move them)")
    PLAN.write_text("\n".join(f"{p}\t{s}" for p, s, _ in out), encoding="utf-8")
    print(f"full list: {PLAN}")
    print("destination: " + ", ".join(sorted({str(d) for d in dests})))

    if not a.apply:
        print("dry run only — nothing moved")
        return
    print(f"moved {apply(out, roots, dests)} files")


if __name__ == "__main__":
    main()
