#!/usr/bin/env bash
# One-time setup on macOS (Apple Silicon recommended). Run from the rekordsound folder:   bash setup-mac.sh
set -e
cd "$(dirname "$0")"

if [ "$(uname -m)" != "arm64" ]; then
  echo "Note: this Terminal is not running natively on Apple Silicon (uname -m = $(uname -m))."
  echo "On an Intel Mac, or a Terminal started under Rosetta, analysis runs on the CPU only and is much slower."
fi

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew is needed first. Install it from https://brew.sh, open a new Terminal, then run this again."
  exit 1
fi

command -v ffmpeg >/dev/null 2>&1 || brew install ffmpeg
command -v node   >/dev/null 2>&1 || brew install node          # only used for YouTube-link search (yt-dlp)

PY=$(command -v python3.12 || command -v python3.11 || true)
if [ -z "$PY" ]; then
  brew install python@3.12
  PY="$(brew --prefix)/bin/python3.12"
fi
echo "Using $PY"

"$PY" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install torch==2.6.0 torchaudio==2.6.0            # default macOS build (includes Apple GPU support)
.venv/bin/pip install -r requirements.txt

.venv/bin/python - <<'EOF'
import torch
print("Apple GPU (mps) available:", bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()))
EOF
echo
echo "Done. Start the app with:   bash start.command"
echo "Then follow the on-screen steps (Import tab): export your collection from Rekordbox as XML and choose it there."
