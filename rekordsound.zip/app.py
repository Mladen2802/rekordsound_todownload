"""rekordsound — similarity search for a Rekordbox library.   python app.py  ->  http://127.0.0.1:7870"""
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
from pathlib import Path
from xml.sax.saxutils import quoteattr
from urllib.parse import quote

import numpy as np
import uvicorn
from fastapi import Body, Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response

import aiffwav
import db
import energy
import library
from bpm import estimate_bpm
from models import SR, decode, download_audio, embed_track, standardize

PORT = 7870
NOPLAY = os.environ.get("REKORDSOUND_NOPLAY") == "1"     # set on the VPS: no audio files there
# Online copy: data comes from `python publish.py` on the main computer, so nothing can be edited here (playlists, import,
# analysis). Searching (library track, link, microphone, upload, text) stays available. Implied by NOPLAY.
READONLY = NOPLAY or os.environ.get("REKORDSOUND_READONLY") == "1"
TOP_K = 100
XML_PATH = Path(os.environ.get("REKORDSOUND_XML", library.DEFAULT_XML))
CACHE = db.ROOT / "data" / "cache"            # transcoded copies of formats browsers can't play (AIFF, ALAC)
CACHE_MAX = 2 * 1024 ** 3
BROWSER_OK ={".mp3", ".m4a", ".mp4", ".aac", ".wav", ".flac", ".ogg", ".opus", ".webm"}

app = FastAPI()


def writable():
    if READONLY:
        raise HTTPException(403, "This online copy is read-only. Change things on the main computer, then run publish.py.")
gpu = threading.Lock()                        # one model job at a time
state_lock = threading.Lock()
state = {"xml_mtime": None, "db_mtime": None, "db_checked": 0}
models = {}
query_cache = {}                              # url -> (title, query vectors dict); memory only


# ---------------------------------------------------------------- state
def get_models(effnet_only=False):
    """-> (clap, mert, effnet); loaded lazily. CLAP/MERT go to the GPU, discogs-effnet runs on the CPU."""
    with gpu:
        if "effnet" not in models:
            from models import EffnetEmbedder
            models["effnet"] = EffnetEmbedder()
        if not effnet_only and "clap" not in models:
            from models import Embedder, MertEmbedder
            models["clap"], models["mert"] = Embedder(), MertEmbedder()
    return models.get("clap"), models.get("mert"), models["effnet"]


AI_MIN = 0.2              # minimum style probability before a predicted ("ai") genre is shown / used in filters


def _ai_genres(v):
    """Per vector row: top-3 Discogs styles and the predicted DJ genre (from discogs-effnet)."""
    if not v["has_effnet"].any():                 # nothing analysed yet (new install): don't load / download the model
        return [None] * len(v["keys"]), [None] * len(v["keys"])
    import genres
    names = genres.style_names()
    Z = genres.dj_scores(v["S"], genres.style_matrix(names))
    styles, ai = [], []
    for i in range(len(v["keys"])):
        if not v["has_effnet"][i]:
            styles.append(None)
            ai.append(None)
            continue
        o = np.argsort(-v["S"][i].astype(np.float32))[:3]
        styles.append([(names[j].split("---")[-1], round(float(v["S"][i][j]), 2)) for j in o])
        g = int(np.argmax(Z[i]))
        ai.append(genres.DJ_GENRES[g] if Z[i, g] >= AI_MIN else None)
    return styles, ai


def _db_mtime():
    return max((p.stat().st_mtime for p in (db.DB_PATH, Path(str(db.DB_PATH) + "-wal")) if p.exists()), default=None)


def S(force_db=False):
    """Library (XML) + vectors (DB), reloaded when either changes (DB at most once a minute)."""
    with state_lock:
        xm = XML_PATH.stat().st_mtime if XML_PATH.exists() else None
        if xm != state["xml_mtime"] or "tracks" not in state:
            # no XML yet (new install): start empty; the Import tab brings the collection in
            tracks, playlists, skipped = library.load(XML_PATH) if xm is not None else ({}, [], 0)
            state.update(tracks=tracks, playlists=playlists, skipped=skipped, xml_mtime=xm, by_key={})
            state.pop("v", None)                                   # row -> track mapping must be rebuilt
            for t in tracks.values():
                state["by_key"].setdefault(library.path_key(t["path"]), t["id"])
        now = time.time()
        if force_db or "v" not in state or now - state["db_checked"] > 60:
            state["db_checked"] = now
            dm = _db_mtime()
            if "v" not in state or dm != state["db_mtime"]:
                v = db.load_vectors()
                v["row_track"] = [state["by_key"].get(k) for k in v["keys"]]   # vector row -> track id
                v["track_row"] = {tid: i for i, tid in enumerate(v["row_track"]) if tid}
                v["styles"], v["ai"] = _ai_genres(v)
                # genres used by the genre filters: the track's own tags, plus the predicted genre when the
                # track has no specific genre (none, or only Electronic / Dance / Pop ...)
                eff = {}
                for tid, t in state["tracks"].items():
                    gs = {g.lower() for g in t["genres"]}
                    i = v["track_row"].get(tid)
                    if i is not None and v["ai"][i] and not library.is_specific(t["genres"]):
                        gs.add(v["ai"][i].lower())
                    eff[tid] = gs
                con = db.connect()
                erows = db.load_energy(con)
                con.close()
                v["energy_cal"] = energy.Calibration([f for _, f, _ in erows]) if len(erows) >= 50 else None
                cal = v["energy_cal"]            # scored here from the stored features, so tracks measured since the last scoring show too
                lv = {k: energy.level(cal.score(f)) for k, f, _ in erows} if cal else {}
                for t in state["tracks"].values():
                    t["energy"] = lv.get(library.path_key(t["path"]))      # 1-10, None until energy.py has run
                state.update(v=v, db_mtime=dm, eff_genres=eff)
        return state


def track_row(st, tid):
    """Vector row for a library track, analysing it on demand if needed (all models, or only discogs-effnet
    for tracks analysed before it existed)."""
    if tid not in st["tracks"]:
        raise HTTPException(404, "Track not in the library")
    row = st["v"]["track_row"].get(tid)
    if row is not None and st["v"]["has_effnet"][row]:
        return st, row
    t = st["tracks"][tid]
    if not os.path.exists(t["path"]):
        if row is not None:
            return st, row
        raise HTTPException(404, f"File is missing: {t['path']}")
    only_eff = row is not None
    clap, mert, eff = get_models(effnet_only=only_eff)
    try:
        audio = decode(t["path"])
        with gpu:
            r = embed_track(None if only_eff else clap, None if only_eff else mert, audio, eff)
    except Exception as e:
        if row is not None:
            return st, row
        raise HTTPException(500, f"Could not analyse this file: {str(getattr(e, 'stderr', e))[-200:]}")
    stt = os.stat(t["path"])
    con = db.connect()
    if only_eff:
        db.save_effnet(con, library.path_key(t["path"]), r)
    else:
        db.save(con, library.path_key(t["path"]), t["path"], stt.st_mtime, stt.st_size, len(audio) / SR, r)
    con.close()
    st = S(force_db=True)
    return st, st["v"]["track_row"][tid]


# ---------------------------------------------------------------- filters
class Filters:
    """All bounds optional. `unknown`: keep tracks whose value is unknown for a field being filtered.
    bpm_pct / key are relative to the source track (ignored when the source has no BPM / key)."""

    def __init__(self, mode="style", bpm_min=None, bpm_max=None, bpm_pct=None, half_double=False,
                 key="any", genres=None, year_min=None, year_max=None, rating_min=None, playlist=None,
                 unknown=True, exclude_genres=None, min_score=None, energy_min=None, energy_max=None,
                 energy_near=None):
        if mode not in ("style", "clap", "mert", "blend"):
            raise HTTPException(400, "mode must be style, clap, mert or blend")
        if key not in ("any", "same", "compat"):
            raise HTTPException(400, "key must be any, same or compat")
        self.mode, self.bpm_min, self.bpm_max, self.bpm_pct, self.half_double = mode, bpm_min, bpm_max, bpm_pct, half_double
        self.key, self.year_min, self.year_max, self.rating_min, self.playlist, self.unknown = \
            key, year_min, year_max, rating_min, playlist, unknown
        self.genres = {g.strip().lower() for g in (genres or "").split("|") if g.strip()}
        self.exclude = {g.strip().lower() for g in (exclude_genres or "").split("|") if g.strip()}
        self.min_score = min_score / 100 if min_score else None     # drop matches below this similarity (%)
        self.energy_min, self.energy_max, self.energy_near = energy_min, energy_max, energy_near

    def bind(self, source):
        """Resolve source-relative filters; returns a predicate over track dicts and a list of notes."""
        notes, keys, bpm_ranges = [], None, []
        sb, sk = (source or {}).get("bpm"), (source or {}).get("camelot")
        if self.bpm_pct:
            if sb:
                f = self.bpm_pct / 100
                for mul in ([1, 0.5, 2] if self.half_double else [1]):
                    bpm_ranges.append((sb * mul * (1 - f), sb * mul * (1 + f)))
            else:
                notes.append("BPM ± % ignored: source BPM unknown")
        if self.bpm_min is not None or self.bpm_max is not None:
            bpm_ranges = [(lo if self.bpm_min is None else max(lo, self.bpm_min),
                           hi if self.bpm_max is None else min(hi, self.bpm_max)) for lo, hi in bpm_ranges] \
                if bpm_ranges else [(self.bpm_min or 0, self.bpm_max or 1e9)]
        if self.key != "any":
            if sk:
                keys = {sk} if self.key == "same" else library.camelot_neighbours(sk)
            else:
                notes.append("key filter ignored: source key unknown")
        e_lo, e_hi = self.energy_min, self.energy_max
        if self.energy_near is not None:                  # +-N levels around the source
            se = (source or {}).get("energy")
            if se:
                e_lo = max(se - self.energy_near, e_lo if e_lo is not None else 1)
                e_hi = min(se + self.energy_near, e_hi if e_hi is not None else 10)
            else:
                notes.append("energy +- ignored: source energy unknown")
        pl = None
        if self.playlist is not None:
            pls = {p["id"]: p for p in S()["playlists"]}
            pl = set(pls[self.playlist]["track_ids"]) if self.playlist in pls else set()
        unk = self.unknown
        eff = S()["eff_genres"]                  # own tags + predicted genre for untagged tracks

        def ok(t):
            if pl is not None and t["id"] not in pl:
                return False
            if self.genres and not self.genres & eff.get(t["id"], set()):
                return False
            if self.exclude and self.exclude & eff.get(t["id"], set()):
                return False
            if self.rating_min and t["rating"] < self.rating_min:
                return False
            if bpm_ranges:
                b = t["bpm"]
                if b is None:
                    if not unk:
                        return False
                elif not any(lo <= b <= hi for lo, hi in bpm_ranges):
                    return False
            if e_lo is not None or e_hi is not None:
                e = t.get("energy")
                if e is None:
                    if not unk:
                        return False
                elif (e_lo is not None and e < e_lo) or (e_hi is not None and e > e_hi):
                    return False
            if keys is not None:
                if t["camelot"] is None:
                    if not unk:
                        return False
                elif t["camelot"] not in keys:
                    return False
            if self.year_min is not None or self.year_max is not None:
                y = t["year"]
                if y is None:
                    if not unk:
                        return False
                elif (self.year_min is not None and y < self.year_min) or (self.year_max is not None and y > self.year_max):
                    return False
            return True
        return ok, notes


def filters(mode: str = "style", bpm_min: float | None = None, bpm_max: float | None = None,
            bpm_pct: float | None = None, half_double: bool = False, key: str = "any",
            genres: str | None = None, year_min: int | None = None, year_max: int | None = None,
            rating_min: int | None = None, playlist: str | None = None, unknown: bool = True,
            exclude_genres: str | None = None, min_score: float | None = None, energy_min: int | None = None,
            energy_max: int | None = None, energy_near: int | None = None):
    return Filters(mode, bpm_min, bpm_max, bpm_pct, half_double, key, genres, year_min, year_max,
                   rating_min, playlist, unknown, exclude_genres, min_score, energy_min, energy_max, energy_near)


def _z(x):
    return (x - x.mean()) / (x.std() + 1e-9)


def rank(st, q, flt: Filters, source=None, exclude=None, k=TOP_K):
    """q: dict(clap=CLAP unit vector, mert=raw MERT vector or None, effnet=raw effnet vector or None).
    Modes: style = discogs-effnet (like cosine.club), clap = vibe, mert = musical, blend = all available, averaged
    as per-query z-scores. Tracks missing a model's vectors fall back to CLAP for that model."""
    v, tracks = st["v"], st["tracks"]
    if not len(v["keys"]):
        return [], []
    sc = v["E"] @ q["clap"]
    zc = _z(sc)
    sm = sf = None
    if q.get("mert") is not None and v["has_mert"] and flt.mode in ("mert", "blend"):
        sm = v["M"] @ standardize(q["mert"], v["mert_mu"], v["mert_sd"])
    hf = v["has_effnet"]
    if q.get("effnet") is not None and hf.any() and flt.mode in ("style", "blend"):
        sf = v["F"] @ db.center(q["effnet"], v["eff_mu"])
        zf = np.where(hf, 0.0, zc)
        zf[hf] = _z(sf[hf])
        sf_shown = np.where(hf, sf, sc)
    if flt.mode == "style" and sf is not None:
        rank_s, shown = zf, sf_shown
    elif flt.mode == "mert" and sm is not None:
        rank_s, shown = sm, sm
    elif flt.mode == "blend":
        parts, raw = [zc], [sc]
        if sm is not None:
            parts.append(_z(sm))
            raw.append(sm)
        if sf is not None:
            parts.append(zf)
            raw.append(sf_shown)
        rank_s, shown = np.mean(parts, 0), np.mean(raw, 0)
    else:
        rank_s, shown = sc, sc
    ok, notes = flt.bind(source)
    out, seen = [], (set(exclude) if isinstance(exclude, (set, frozenset)) else {exclude})
    qc16 = q["clap"].astype(np.float16)
    for i in np.argsort(-rank_s):
        if flt.min_score is not None and shown[i] < flt.min_score:
            continue
        tid = v["row_track"][i]
        if tid is None or tid in seen or not ok(tracks[tid]):
            continue
        seen.add(tid)
        best = int(np.argmax(v["C"][i] @ qc16))
        out.append(dict(id=tid, score=round(float(shown[i]), 4), t=int(v["clip_starts"][i][best])))
        if len(out) >= k:
            break
    return out, notes


# ---------------------------------------------------------------- API
PUBLIC = ("id", "title", "artist", "album", "genre", "label", "bpm", "camelot", "key", "year", "rating", "duration",
          "playlists", "comments", "energy")


@app.get("/")
def home():
    return FileResponse(db.ROOT / "static" / "index.html")


@app.get("/api/library")
def api_library():
    st = S()
    v = st["v"]
    tr = v["track_row"]
    tracks = []
    for t in st["tracks"].values():
        d = dict({k: t[k] for k in PUBLIC}, analysed=t["id"] in tr)
        i = tr.get(t["id"])
        if i is not None and v["has_effnet"][i]:
            d["styles"] = v["styles"][i]
            if v["ai"][i] and not library.is_specific(t["genres"]):
                d["ai_genre"] = v["ai"][i]
        tracks.append(d)
    genres = {}
    for gs in st["eff_genres"].values():
        for g in gs:
            genres[g] = genres.get(g, 0) + 1
    canon = {g.lower(): g for t in st["tracks"].values() for g in t["genres"]}
    import genres as G
    canon.update({g.lower(): g for g in G.DJ_GENRES})
    genres = {canon.get(g, g): n for g, n in genres.items()}
    return dict(tracks=tracks, analysed=len(tr), playback=not NOPLAY, readonly=READONLY,
                playlists=[dict(id=p["id"], path=p["path"], count=len(p["track_ids"])) for p in st["playlists"]],
                genres=sorted(genres.items(), key=lambda g: -g[1]))


def _audio_file(t):
    p = Path(t["path"])
    if not p.exists():
        raise HTTPException(404, "File is missing")
    ext = p.suffix.lower()
    if ext in BROWSER_OK and not (ext in (".m4a", ".mp4") and _codec(p) == "alac"):
        return p
    CACHE.mkdir(parents=True, exist_ok=True)
    h = hashlib.sha1(f"{p}|{p.stat().st_mtime}".encode()).hexdigest()[:16]
    out = CACHE / f"{h}.mp3"
    if not out.exists():
        tmp = out.with_suffix(".tmp.mp3")
        subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", str(p), "-vn", "-map_metadata", "-1",
                        "-c:a", "libmp3lame", "-q:a", "0", str(tmp)], check=True)
        tmp.replace(out)
        files = sorted(CACHE.glob("*.mp3"), key=lambda f: f.stat().st_atime, reverse=True)
        used = 0
        for f in files:                          # keep the cache under CACHE_MAX, oldest first out
            used += f.stat().st_size
            if used > CACHE_MAX and f != out:
                f.unlink(missing_ok=True)
    return out


_codecs = {}


def _codec(p):
    if p not in _codecs:
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name",
                            "-of", "csv=p=0", str(p)], capture_output=True, text=True)
        _codecs[p] = r.stdout.strip()
    return _codecs[p]


_aiff = {}


@app.get("/api/audio/{tid}")
def api_audio(tid: str, request: Request):
    if NOPLAY:
        raise HTTPException(404, "Playback is disabled on this server")
    t = S()["tracks"].get(tid)
    if not t:
        raise HTTPException(404, "Track not in the library")
    p = Path(t["path"])
    if p.suffix.lower() in (".aif", ".aiff") and p.exists():
        k = (str(p), p.stat().st_mtime)
        if k not in _aiff:
            _aiff[k] = aiffwav.parse(p)
        if _aiff[k]:                              # plain PCM: serve as WAV on the fly, no transcoding
            return aiffwav.response(p, _aiff[k], request.headers.get("range"))
    return FileResponse(_audio_file(t))          # Starlette handles HTTP Range (seeking)


COVERS = db.ROOT / "data" / "cache" / "covers"          # 128 px JPEG thumbnails, made on first request
ART_FILES = [f"{n}{e}" for n in ("cover", "folder") for e in (".jpg", ".png")]


def _embedded_art(p):
    """Cover bytes from the file's own tags (ID3 APIC in AIFF / WAV / MP3, FLAC picture, MP4 covr) or None."""
    import mutagen
    f = mutagen.File(p)
    if f is None:
        return None
    if getattr(f, "pictures", None):
        return f.pictures[0].data
    tags = f.tags
    if tags is None:
        return None
    if hasattr(tags, "getall") and (apic := tags.getall("APIC")):
        return apic[0].data
    if "covr" in tags and tags["covr"]:
        return bytes(tags["covr"][0])
    return None


def _folder_art(p):
    for n in ART_FILES:
        f = p.parent / n
        if f.is_file():
            return f.read_bytes()
    return None


@app.get("/api/cover/{tid}")
def api_cover(tid: str):
    if NOPLAY:
        raise HTTPException(404, "No cover art on this server")
    t = S()["tracks"].get(tid)
    p = Path(t["path"]) if t else None
    if not p or not p.exists():
        raise HTTPException(404, "No cover")
    h = hashlib.sha1(f"{p}|{p.stat().st_mtime}".encode()).hexdigest()[:16]
    jpg, none = COVERS / f"{h}.jpg", COVERS / f"{h}.none"
    hdr = {"Cache-Control": "public, max-age=86400"}
    if jpg.exists():
        return FileResponse(jpg, media_type="image/jpeg", headers=hdr)
    if none.exists():
        raise HTTPException(404, "No cover")
    COVERS.mkdir(parents=True, exist_ok=True)
    try:
        data = _embedded_art(p) or _folder_art(p)
    except Exception:
        data = None
    tmp = jpg.with_name(f"{h}.{threading.get_ident()}.tmp.jpg")
    if data:
        r = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", "pipe:0", "-an", "-vf",
                            "scale=128:128:force_original_aspect_ratio=increase,crop=128:128", "-frames:v", "1",
                            "-q:v", "4", str(tmp)], input=data, capture_output=True)
        if r.returncode == 0 and tmp.exists():
            tmp.replace(jpg)
            return FileResponse(jpg, media_type="image/jpeg", headers=hdr)
    tmp.unlink(missing_ok=True)
    none.touch()
    raise HTTPException(404, "No cover")


@app.get("/api/similar")
def api_similar(id: str, flt: Filters = Depends(filters)):
    st, i = track_row(S(), id)
    v = st["v"]
    t = st["tracks"][id]
    q = dict(clap=v["E"][i], mert=v["M_raw"][i], effnet=v["F_raw"][i] if v["has_effnet"][i] else None)
    res, notes = rank(st, q, flt, source=t, exclude=id)
    return dict(source=dict(id=id), results=res, notes=notes)


def embed_audio(audio):
    clap, mert, eff = get_models()
    with gpu:
        r = embed_track(clap, mert, audio, eff)
    b, _ = estimate_bpm(audio)                       # tempo of the query (library tracks use their Rekordbox BPM)
    cal = S()["v"].get("energy_cal")                 # energy 1-10 on the library's scale (None until energy.py has run)
    f = energy.features(audio, b) if cal else None
    return dict(clap=r["clap"], mert=r["mert"], effnet=r["effnet"], bpm=b, energy=energy.level(cal.score(f)) if f else None)


def with_bpm(src, q, notes):
    """Add the detected BPM to a non-library source; returns the source dict used for BPM filters."""
    if q.get("bpm"):
        src["bpm"] = q["bpm"]
        notes.insert(0, f"BPM {q['bpm']:g} detected from the audio (can be half/double time)")
    if q.get("energy"):
        src["energy"] = q["energy"]
        notes.append(f"energy {q['energy']} estimated from the audio (loudness of a recording or link is less reliable)")
    return src


YT = re.compile(r"(?:v=|youtu\.be/|shorts/|embed/|live/)([\w-]{11})")
VOCAROO = re.compile(r"^https?://(?:www\.)?(?:vocaroo\.com|voca\.ro)/(?:i/)?([\w-]{6,})/?$")


BANDCAMP = re.compile(r"^https?://([\w-]+\.bandcamp\.com/(?:track|album)/[\w-]+)")


@app.get("/api/link")
def api_link(url: str, brief: int = 0, flt: Filters = Depends(filters)):
    """Search with a YouTube / Bandcamp / Vocaroo link. Audio is downloaded to a temp dir and deleted.
    brief=N: also return the top N results with their metadata (used by the browser userscript)."""
    url = url.strip()
    if m := YT.search(url):
        canon, kind = f"https://www.youtube.com/watch?v={m.group(1)}", "YouTube"
    elif m := BANDCAMP.match(url):
        canon, kind = f"https://{m.group(1)}", "Bandcamp"
    elif m := VOCAROO.match(url):
        canon, kind = f"https://vocaroo.com/{m.group(1)}", "Vocaroo"
    else:
        raise HTTPException(400, "Only YouTube, Bandcamp and Vocaroo links are supported")
    if canon not in query_cache:
        try:
            audio, title = download_audio(canon, with_title=True)
        except Exception as e:
            raise HTTPException(502, f"Could not download that link: {str(getattr(e, 'stderr', e))[-200:]}")
        query_cache[canon] = (title if kind == "YouTube" else "Vocaroo recording", embed_audio(audio))
    title, q = query_cache[canon]
    src = dict(title=title, artist=kind, link=canon)
    res, notes = rank(S(), q, flt, source=dict(bpm=q.get("bpm"), energy=q.get("energy")))
    out = dict(source=with_bpm(src, q, notes), results=res, notes=notes)
    if brief:
        tr = S()["tracks"]
        out["top"] = [dict({k: tr[r["id"]][k] for k in ("id", "title", "artist", "bpm", "camelot", "energy")}, score=r["score"], t=r["t"])
                      for r in res[:brief] if r["id"] in tr]
    return out


@app.get("/api/text")
def api_text(q: str, flt: Filters = Depends(filters)):
    clap, _, _ = get_models()
    with gpu:
        vec = clap.text(q)
    flt.mode = "clap"                              # text search is CLAP-only
    res, notes = rank(S(), dict(clap=vec), flt)
    return dict(source=dict(title=f"“{q}”", artist="text search"), results=res, notes=notes)


@app.post("/api/upload")
def api_upload(file: UploadFile = File(...), flt: Filters = Depends(filters)):
    suffix = Path(file.filename or "x.mp3").suffix
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
        f.write(file.file.read())
    try:
        audio = decode(f.name)
        if len(audio) < 2 * 48000:                       # decode() is 48 kHz mono
            raise HTTPException(400, "Recording is too short (need at least 2 s of audio)")
        peak = float(abs(audio).max())
        if peak < 1e-4:
            raise HTTPException(400, "Recording is silent — check the microphone")
        if peak < 0.5:                                   # quiet mic capture: normalise
            audio = audio * (0.9 / peak)
        q = embed_audio(audio)
    except subprocess.CalledProcessError:
        raise HTTPException(400, "Could not read that audio file")
    finally:
        os.unlink(f.name)
    res, notes = rank(S(), q, flt, source=dict(bpm=q.get("bpm"), energy=q.get("energy")))
    kind = "microphone" if (file.filename or "").startswith("recording.") else "uploaded file"
    return dict(source=with_bpm(dict(title=file.filename, artist=kind), q, notes), results=res, notes=notes)


def _location(path):
    """File path -> Rekordbox Location: file://localhost/C:/Music/a.mp3 (Windows) or file://localhost/Users/me/a.mp3 (macOS)."""
    p = path.replace("\\", "/") if os.sep == "\\" else path
    return "file://localhost" + ("" if p.startswith("/") else "/") + quote(p, safe="/:")


def _safe_name(s):
    return re.sub(r'[\\/:*?"<>|]+', "_", s).strip() or "rekordsound"


@app.post("/api/export")
def api_export(ids: list[str] = Body(...), name: str = Body("rekordsound"), format: str = Body("m3u8")):
    tracks = S()["tracks"]
    sel = [tracks[i] for i in ids if i in tracks]
    if not sel:
        raise HTTPException(400, "No tracks to export")
    fname = _safe_name(name)
    if format == "m3u8":
        lines = ["#EXTM3U", f"#PLAYLIST:{name}"]
        for t in sel:
            lines += [f"#EXTINF:{int(t['duration'] or -1)},{t['artist']} - {t['title']}", t["path"]]
        body, ext, mime = "\r\n".join(lines) + "\r\n", "m3u8", "audio/x-mpegurl"
    elif format == "xml":
        # Rekordbox XML with only identifying fields, so importing can't overwrite cues/beatgrids.
        rows = []
        for t in sel:
            loc = _location(t["path"])
            attrs = dict(TrackID=t["id"], Name=t["title"], Artist=t["artist"], Location=loc)
            rows.append("    <TRACK " + " ".join(f"{k}={quoteattr(str(v))}" for k, v in attrs.items()) + "/>")
        keys = "\n".join(f'        <TRACK Key="{t["id"]}"/>' for t in sel)
        body = ('<?xml version="1.0" encoding="UTF-8"?>\n<DJ_PLAYLISTS Version="1.0.0">\n'
                '  <PRODUCT Name="rekordsound" Version="0.1" Company=""/>\n'
                f'  <COLLECTION Entries="{len(sel)}">\n' + "\n".join(rows) + "\n  </COLLECTION>\n"
                '  <PLAYLISTS>\n    <NODE Type="0" Name="ROOT" Count="1">\n'
                f'      <NODE Name={quoteattr(name)} Type="1" KeyType="0" Entries="{len(sel)}">\n'
                f"{keys}\n      </NODE>\n    </NODE>\n  </PLAYLISTS>\n</DJ_PLAYLISTS>\n")
        ext, mime = "xml", "application/xml"
    else:
        raise HTTPException(400, "format must be m3u8 or xml")
    return Response(body.encode("utf-8"), media_type=mime,
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}.{ext}"})


# ---------------------------------------------------------------- playlists (app-side copies, stored by path key)
def _db_call(fn, *a):
    con = db.connect()
    try:
        return fn(con, *a)
    finally:
        con.close()


def _clean_name(name):
    name = (name or "").strip()[:120]
    if not name:
        raise HTTPException(400, "Playlist needs a name")
    return name


def _keys_for(ids):
    tr = S()["tracks"]
    return [library.path_key(tr[i]["path"]) for i in ids if i in tr]


def _rows_for(keys):
    """Ordered keys -> rows for the UI. Tracks not in the current collection come back as missing rows."""
    st = S()
    out = []
    for k in keys:
        tid = st["by_key"].get(k)
        if tid:
            out.append(dict(id=tid, key=k))
        else:
            out.append(dict(id="missing:" + k, key=k, missing=True, title=Path(k).stem, artist="not in the collection"))
    return out


def _rb_playlist(pid):
    try:
        n = int(pid[3:])
        p = S()["playlists"][n]
    except (ValueError, IndexError):
        raise HTTPException(404, "Playlist not found")
    return p


@app.get("/api/playlists")
def api_playlists():
    st = S()
    return dict(mine=_db_call(db.list_playlists),
                rekordbox=[dict(id=f"rb:{p['id']}", name=p["name"], path=p["path"], count=len(p["track_ids"]))
                           for p in st["playlists"]])


@app.get("/api/playlists/{pid}")
def api_playlist(pid: str):
    if pid.startswith("rb:"):
        p = _rb_playlist(pid)
        return dict(id=pid, name=p["name"], path=p["path"], readonly=True,
                    tracks=[dict(id=i, key=library.path_key(S()["tracks"][i]["path"])) for i in p["track_ids"]])
    r = _db_call(db.get_playlist, int(pid)) if pid.isdigit() else None
    if not r:
        raise HTTPException(404, "Playlist not found")
    meta, keys = r
    return dict(meta, readonly=False, tracks=_rows_for(keys))


@app.get("/api/playlists/{pid}/similar")
def api_playlist_similar(pid: str, hide_in: str = "none", flt: Filters = Depends(filters)):
    """Tracks that sound like the playlist as a whole: the members' vectors are averaged into one query.
    Members that are not analysed yet are skipped (not analysed on demand).
    hide_in: none | any | mine | rb - drop tracks that are already in another playlist (any / mine / Rekordbox's).
    Every result lists the other playlists it is in (`pl` = first names, `npl` = count)."""
    if hide_in not in ("none", "any", "mine", "rb"):
        raise HTTPException(400, "hide_in must be none, any, mine or rb")
    st = S()
    by_key = st["by_key"]
    if pid.startswith("rb:"):
        tids, cur_rb, cur_mine = list(_rb_playlist(pid)["track_ids"]), pid[3:], None
    else:
        r = _db_call(db.get_playlist, int(pid)) if pid.isdigit() else None
        if not r:
            raise HTTPException(404, "Playlist not found")
        tids, cur_rb, cur_mine = [by_key[k] for k in r[1] if k in by_key], None, int(pid)
    mine = _db_call(db.playlists_by_key)                       # track key -> [(id, name)] of my playlists

    def other(t):
        """(Rekordbox playlist names, my playlist names) this track is in, not counting the open playlist."""
        rb = [st["playlists"][int(i)]["path"] for i in t["playlists"] if i != cur_rb]
        my = [n for i, n in mine.get(library.path_key(t["path"]), []) if i != cur_mine]
        return rb, my
    others = {t["id"]: other(t) for t in st["tracks"].values()}
    skip = set(tids)
    if hide_in != "none":
        for tid, (rb, my) in others.items():
            if (hide_in in ("any", "rb") and rb) or (hide_in in ("any", "mine") and my):
                skip.add(tid)
    v = st["v"]
    rows = sorted({v["track_row"][t] for t in tids if t in v["track_row"]})
    if not rows:
        raise HTTPException(400, "None of the tracks in this playlist are analysed yet")
    ce = v["E"][rows].mean(0)
    q = dict(clap=(ce / (np.linalg.norm(ce) + 1e-9)).astype(np.float32), mert=v["M_raw"][rows].mean(0), effnet=None)
    eff = [i for i in rows if v["has_effnet"][i]]
    if eff:
        q["effnet"] = v["F_raw"][eff].mean(0)
    res, notes = rank(st, q, flt, source=None, exclude=skip)
    for r in res:
        names = others[r["id"]][1] + others[r["id"]][0]        # mine first
        r["npl"], r["pl"] = len(names), names[:3]
    return dict(results=res, notes=notes, used=len(rows), total=len(set(tids)))


@app.post("/api/playlists", dependencies=[Depends(writable)])
def api_playlist_create(name: str = Body(...), ids: list[str] = Body([]), copy_from: str | None = Body(None)):
    source = None
    if copy_from:
        if not copy_from.startswith("rb:"):
            raise HTTPException(400, "copy_from must be a Rekordbox playlist")
        p = _rb_playlist(copy_from)
        ids, source = p["track_ids"], p["path"]
    pid = _db_call(lambda con: db.create_playlist(con, _clean_name(name), _keys_for(ids), source))
    return dict(id=str(pid))


@app.patch("/api/playlists/{pid}", dependencies=[Depends(writable)])
def api_playlist_rename(pid: int, name: str = Body(..., embed=True)):
    if not _db_call(db.rename_playlist, pid, _clean_name(name)):
        raise HTTPException(404, "Playlist not found")
    return dict(ok=True)


@app.delete("/api/playlists/{pid}", dependencies=[Depends(writable)])
def api_playlist_delete(pid: int):
    if not _db_call(db.delete_playlist, pid):
        raise HTTPException(404, "Playlist not found")
    return dict(ok=True)


@app.put("/api/playlists/{pid}/tracks", dependencies=[Depends(writable)])
def api_playlist_tracks(pid: int, ids: list[str] = Body(..., embed=True)):
    """Replace the ordered track list. Ids are track ids; 'missing:<key>' entries keep tracks that are not in the collection."""
    keys = []
    for i in ids:
        if i.startswith("missing:"):
            keys.append(i[8:])
        else:
            keys += _keys_for([i])
    if not _db_call(db.set_playlist_keys, pid, keys):
        raise HTTPException(404, "Playlist not found")
    return dict(ok=True, count=len(keys))


# ---------------------------------------------------------------- import an updated collection + analysis
PENDING_XML = db.ROOT / "data" / "import_pending.xml"
LIST_MAX = 200
job = {"proc": None, "lines": [], "started": None}


def _brief(t):
    return {k: t[k] for k in ("id", "title", "artist", "bpm", "camelot") if k in t} | dict(path=t["path"])


@app.post("/api/import/preview", dependencies=[Depends(writable)])
def api_import_preview(file: UploadFile = File(...)):
    """Parse an exported collection, compare it to the current one and report what is new / removed / unanalysed.
    Nothing is replaced until /api/import/apply."""
    PENDING_XML.parent.mkdir(exist_ok=True)
    tmp = PENDING_XML.with_suffix(".tmp")
    with open(tmp, "wb") as f:
        shutil.copyfileobj(file.file, f)
    try:
        tracks, playlists, skipped = library.load(tmp)
        if not tracks and not playlists:
            raise ValueError("no tracks or playlists found")
    except Exception as e:
        tmp.unlink(missing_ok=True)
        raise HTTPException(400, f"Not a valid Rekordbox collection XML: {str(e)[:200]}")
    tmp.replace(PENDING_XML)
    st = S()
    d = library.diff(st["tracks"], st["playlists"], tracks, playlists)
    con = db.connect()
    done = db.analysed_keys(con)
    no_eff = {k for (k,) in con.execute("SELECT key FROM audio WHERE effnet IS NULL")}
    con.close()
    ready, notfound, backfill, seen = [], [], 0, set()
    for t in tracks.values():
        k = library.path_key(t["path"])
        if k in seen:
            continue
        seen.add(k)
        if k in done:
            backfill += k in no_eff
        elif os.path.exists(t["path"]):
            ready.append(t)
        else:
            notfound.append(t)
    cut = lambda xs: [_brief(t) for t in xs[:LIST_MAX]]
    return dict(tracks=len(tracks), playlists=len(playlists), skipped=skipped,
                current=dict(tracks=len(st["tracks"]), playlists=len(st["playlists"])),
                added=dict(n=len(d["added"]), items=cut(d["added"])),
                removed=dict(n=len(d["removed"]), items=cut(d["removed"])),
                playlists_added=d["playlists_added"], playlists_removed=d["playlists_removed"],
                playlists_changed=d["playlists_changed"],
                unanalysed=dict(ready=dict(n=len(ready), items=cut(ready)), notfound=dict(n=len(notfound), items=cut(notfound)),
                                effnet_backfill=backfill))


@app.post("/api/import/apply", dependencies=[Depends(writable)])
def api_import_apply():
    if not PENDING_XML.exists():
        raise HTTPException(400, "Nothing to apply — choose an XML file first")
    XML_PATH.parent.mkdir(exist_ok=True)
    backup = None
    if XML_PATH.exists():
        backup = XML_PATH.with_name(f"{XML_PATH.stem}.{time.strftime('%Y%m%d-%H%M%S')}{XML_PATH.suffix}")
        shutil.copy2(XML_PATH, backup)
    os.replace(PENDING_XML, XML_PATH)
    st = S(force_db=True)
    return dict(ok=True, tracks=len(st["tracks"]), playlists=len(st["playlists"]), backup=backup.name if backup else None)


def _job_running():
    return job["proc"] is not None and job["proc"].poll() is None


def _pump(proc):
    for line in proc.stdout:
        job["lines"].append(line.rstrip())
        del job["lines"][:-200]


@app.post("/api/analyze", dependencies=[Depends(writable)])
def api_analyze():
    if NOPLAY:
        raise HTTPException(403, "Analysis is disabled on this server")
    if _job_running():
        raise HTTPException(409, "Analysis is already running")
    proc = subprocess.Popen([sys.executable, "-u", str(db.ROOT / "analyze.py"), "--xml", str(XML_PATH)],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                            errors="replace", cwd=db.ROOT)
    job.update(proc=proc, lines=[], started=time.time())
    threading.Thread(target=_pump, args=(proc,), daemon=True).start()
    return dict(ok=True)


@app.get("/api/analyze/status")
def api_analyze_status():
    lines = job["lines"]
    prog = next((m for l in reversed(lines) if (m := re.match(r"\[(\d+)/(\d+)\] ([\d.]+)s/track, ETA ([\d.]+) h", l))), None)
    running = _job_running()
    return dict(running=running, started=job["started"], done=bool(job["proc"]) and not running,
                n=int(prog[1]) if prog else 0, total=int(prog[2]) if prog else 0, eta_h=float(prog[4]) if prog else None,
                exit=None if running or not job["proc"] else job["proc"].returncode, tail=lines[-5:])


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    S()
    lan = "--lan" in sys.argv                    # also reachable from other devices on this network (no login!)
    print(f"{len(state['tracks'])} tracks, {len(state['v']['track_row'])} analysed — http://127.0.0.1:{PORT}")
    if lan:
        import socket
        try:                                     # the address other devices should use (no packet is sent)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("10.255.255.255", 1))
                ip = s.getsockname()[0]
        except OSError:
            ip = socket.gethostbyname(socket.gethostname())
        print(f"LAN mode: open http://{ip}:{PORT} from another device on this network. There is no login — trusted networks only.")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    uvicorn.run(app, host="0.0.0.0" if lan else "127.0.0.1", port=PORT, log_level="warning")
