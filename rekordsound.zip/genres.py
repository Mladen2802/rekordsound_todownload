"""Predict a DJ genre (from discogs-effnet's 400 Discogs styles) for tracks with no / only a generic genre,
and write it into the files' tags.

    python genres.py eval                    # accuracy on tracks that already have a known DJ genre (no writes)
    python genres.py predict                 # store predictions in data/library.db (no file writes)
    python genres.py write --dry-run         # list what would change
    python genres.py write [--min-confidence 0.3]   # write Genre tag into the files (originals are backed up)
    python genres.py undo                    # restore original Genre tags from the backup

Only analysed tracks get predictions. Never touches Rekordbox's database: after `write`, select the tracks in
Rekordbox and use "Reload Tag" to pick up the new genre.
"""
import argparse
import os
import sys

import numpy as np

import db
import library

DJ_GENRES = [
    "House", "Deep House", "Tech House", "Progressive House", "Garage House", "Italo House", "Acid House",
    "Techno", "Minimal", "Electro", "Breaks", "Trance", "Disco", "Nu-Disco", "Italo-Disco", "Boogie", "Funk",
    "Soul", "Jazz", "Jazz-Funk", "Downtempo", "Ambient", "New Age", "Synth-pop", "New Wave", "Dub",
    "Reggae", "Latin", "Brazilian", "Afro", "Hip Hop", "R&B", "Pop", "Rock",
]
# Discogs style (as predicted by discogs-effnet) -> DJ genre. Keys are "Parent---Style" or just "Parent"
# (applies to every style of that parent unless the full name is listed). Unlisted styles don't count.
STYLE_TO_DJ = {
    "Electronic---Acid House": "Acid House", "Electronic---Acid": "Acid House",
    "Electronic---Deep House": "Deep House", "Electronic---Beatdown": "Deep House",
    "Electronic---Garage House": "Garage House", "Electronic---Italo House": "Italo House",
    "Electronic---Progressive House": "Progressive House", "Electronic---Tech House": "Tech House",
    **{f"Electronic---{s}": "House" for s in ("House", "Ghetto House", "Hip-House", "Tribal House", "Hard House",
                                              "Electro House", "Euro House", "Tropical House", "Speed Garage")},
    **{f"Electronic---{s}": "Techno" for s in ("Techno", "Deep Techno", "Dub Techno", "Hard Techno", "New Beat")},
    "Electronic---Minimal": "Minimal", "Electronic---Minimal Techno": "Minimal",
    "Electronic---Electro": "Electro", "Electronic---Freestyle": "Electro",
    **{f"Electronic---{s}": "Breaks" for s in ("Breaks", "Breakbeat", "Big Beat", "Progressive Breaks", "Broken Beat")},
    **{f"Electronic---{s}": "Trance" for s in ("Trance", "Progressive Trance", "Tech Trance", "Goa Trance", "Psy-Trance")},
    "Electronic---Disco": "Disco", "Electronic---Euro-Disco": "Disco", "Electronic---Hi NRG": "Disco",
    "Electronic---Nu-Disco": "Nu-Disco", "Electronic---Italo-Disco": "Italo-Disco", "Electronic---Italodance": "Italo-Disco",
    "Electronic---Synth-pop": "Synth-pop", "Electronic---Synthwave": "Synth-pop", "Electronic---New Wave": "New Wave",
    "Electronic---Ambient": "Ambient", "Electronic---Dark Ambient": "Ambient", "Electronic---Drone": "Ambient",
    "Electronic---New Age": "New Age",
    **{f"Electronic---{s}": "Downtempo" for s in ("Downtempo", "Trip Hop", "Chillwave", "Future Jazz")},
    "Electronic---Acid Jazz": "Jazz-Funk", "Electronic---Jazzdance": "Jazz-Funk",
    "Electronic---Dub": "Dub", "Electronic---Hip Hop": "Hip Hop", "Electronic---Latin": "Latin",
    "Funk / Soul": "Soul", "Funk / Soul---Disco": "Disco", "Funk / Soul---Boogie": "Boogie",
    "Funk / Soul---Funk": "Funk", "Funk / Soul---P.Funk": "Funk", "Funk / Soul---Free Funk": "Funk",
    "Funk / Soul---Psychedelic": "Funk", "Funk / Soul---Afrobeat": "Afro",
    "Funk / Soul---Contemporary R&B": "R&B", "Funk / Soul---New Jack Swing": "R&B", "Funk / Soul---Swingbeat": "R&B",
    "Jazz": "Jazz", "Jazz---Jazz-Funk": "Jazz-Funk", "Jazz---Soul-Jazz": "Jazz-Funk", "Jazz---Bossa Nova": "Brazilian",
    "Jazz---Afrobeat": "Afro", "Jazz---Latin Jazz": "Latin", "Jazz---Afro-Cuban Jazz": "Latin",
    "Latin": "Latin", **{f"Latin---{s}": "Brazilian" for s in ("Baião", "Batucada", "Bossanova", "MPB", "Samba", "Forró")},
    "Folk, World, & Country---African": "Afro", "Folk, World, & Country---Highlife": "Afro",
    "Folk, World, & Country---Soukous": "Afro",
    "Hip Hop": "Hip Hop", "Hip Hop---RnB/Swing": "R&B", "Hip Hop---Trip Hop": "Downtempo", "Hip Hop---Electro": "Electro",
    "Reggae": "Reggae", "Reggae---Dub": "Dub",
    "Pop": "Pop", "Rock": "Rock", "Rock---New Wave": "New Wave", "Rock---Post-Punk": "New Wave",
    "Rock---Coldwave": "New Wave", "Rock---Lounge": "Downtempo",
}


def style_matrix(style_names):
    """-> (n_styles, n_dj) 0/1 matrix mapping each Discogs style onto DJ_GENRES."""
    W = np.zeros((len(style_names), len(DJ_GENRES)), np.float32)
    for i, s in enumerate(style_names):
        g = STYLE_TO_DJ.get(s, STYLE_TO_DJ.get(s.split("---")[0]))
        if g in DJ_GENRES:
            W[i, DJ_GENRES.index(g)] = 1
    return W


def dj_scores(S, W):
    """Style probabilities (n, 400) -> DJ-genre scores (n, G): strongest mapped style per genre."""
    S = np.asarray(S, np.float32)
    return np.stack([(S * W[:, g]).max(1) for g in range(W.shape[1])], 1)
# existing (cleaned) library genres -> DJ genres, used only to measure accuracy in `eval`
TO_DJ = {
    "Funk / Soul": ["Funk", "Soul"], "African": ["Afro"], "Kwaito": ["Afro"], "Afro House": ["Afro", "House"],
    "Euro House": ["House"], "Smooth Jazz": ["Jazz"], "Future Jazz": ["Jazz"], "Acid Jazz": ["Jazz-Funk"],
    "Fusion": ["Jazz"], "UK Street Soul": ["Soul", "R&B"], "Ambient House": ["Ambient", "House"],
    "Minimal Techno": ["Minimal", "Techno"], "Hi NRG": ["Synth-pop"], "Synthpop": ["Synth-pop"],
    "Dancehall": ["Reggae"], "Zouk": ["Latin"], "Salsa": ["Latin"], "Samba": ["Brazilian"], "MPB": ["Brazilian"],
}


def labels(genres):
    out = set()
    for g in genres:
        if g in DJ_GENRES:
            out.add(g)
        out.update(TO_DJ.get(g, []))
    return out


def style_names():
    import json
    from models import _effnet_files
    return json.loads(_effnet_files()[1].read_text(encoding="utf-8", errors="replace"))["classes"]


def scores():
    """-> (vectors dict, DJ-genre scores (n, G) from discogs-effnet style probabilities; rows without effnet are 0)."""
    v = db.load_vectors()
    if not v["has_effnet"].any():
        sys.exit("no tracks with discogs-effnet yet — run analyze.py first")
    return v, dj_scores(v["S"], style_matrix(style_names()))


def tracks_by_key():
    tracks, _, _ = library.load()
    out = {}
    for t in tracks.values():
        out.setdefault(library.path_key(t["path"]), t)
    return out


def cmd_eval(args):
    v, Z = scores()
    tk = tracks_by_key()
    n = top1 = top3 = 0
    per = {}
    for i, key in enumerate(v["keys"]):
        t = tk.get(key)
        lab = labels(t["genres"]) if t else set()
        if not lab or not v["has_effnet"][i]:
            continue
        order = [DJ_GENRES[j] for j in np.argsort(-Z[i])]
        n += 1
        top1 += order[0] in lab
        top3 += bool(lab & set(order[:3]))
        for g in lab:
            a = per.setdefault(g, [0, 0])
            a[0] += 1
            a[1] += order[0] in lab
    if not n:
        print("no analysed tracks with a known DJ genre")
        return
    chance = np.mean([len(labels(tk[k]["genres"])) / len(DJ_GENRES) for k in v["keys"] if k in tk and labels(tk[k]["genres"])])
    print(f"{n} tracks with known DJ genres: top-1 {top1 / n:.0%}, top-3 {top3 / n:.0%}  (random guess ≈ {chance:.0%})")
    for g, (c, h) in sorted(per.items(), key=lambda x: -x[1][0]):
        print(f"  {g:18} {c:5} tracks, top-1 hit {h / c:.0%}")


def cmd_predict(args):
    v, Z = scores()
    tk = tracks_by_key()
    con = db.connect()
    con.execute("DELETE FROM genre_pred")
    n, counts = 0, {}
    for i, key in enumerate(v["keys"]):
        t = tk.get(key)
        if not t or library.is_specific(t["genres"]) or not v["has_effnet"][i]:
            continue
        j = np.argsort(-Z[i])
        g, g2 = DJ_GENRES[j[0]], DJ_GENRES[j[1]]
        conf = float(Z[i, j[0]])                         # probability of the strongest matching Discogs style
        con.execute("INSERT INTO genre_pred VALUES (?,?,?,?)", (key, g, g2, round(conf, 3)))
        counts[g] = counts.get(g, 0) + 1
        n += 1
    con.commit()
    con.close()
    print(f"{n} predictions stored (tracks without a specific genre)")
    print("  " + ", ".join(f"{g} {c}" for g, c in sorted(counts.items(), key=lambda x: -x[1])))


# ---------------------------------------------------------------- tags
def read_genre(path):
    import mutagen
    f = mutagen.File(path)
    if f is None:
        raise ValueError("unsupported file")
    if f.tags is None:
        return None
    if hasattr(f.tags, "getall"):                       # ID3 (MP3, AIFF, WAV)
        fr = f.tags.getall("TCON")
        return "; ".join(str(x) for fr_ in fr for x in fr_.text) if fr else None
    vals = f.tags.get("genre") or f.tags.get("GENRE")  # Vorbis (FLAC/OGG)
    return "; ".join(vals) if vals else None


def write_genre(path, genre):
    """genre=None removes the tag."""
    import mutagen
    from mutagen.id3 import TCON
    f = mutagen.File(path)
    if f is None:
        raise ValueError("unsupported file")
    if f.tags is None:
        f.add_tags()
    if hasattr(f.tags, "getall"):
        f.tags.delall("TCON")
        if genre:
            f.tags.add(TCON(encoding=3, text=[genre]))
    elif hasattr(f.tags, "__setitem__") and f.__class__.__name__ in ("FLAC", "OggVorbis", "OggOpus"):
        for k in [k for k in f.tags.keys() if k.lower() == "genre"]:
            del f.tags[k]
        if genre:
            f.tags["genre"] = [genre]
    else:
        raise ValueError(f"tag type {type(f.tags).__name__} not supported")
    f.save()


def _touch_db(con, key, path):
    st = os.stat(path)
    con.execute("UPDATE audio SET mtime=?, size=? WHERE key=?", (st.st_mtime, st.st_size, key))


def cmd_write(args):
    con = db.connect()
    rows = con.execute("SELECT p.key, a.path, p.genre, p.confidence FROM genre_pred p JOIN audio a ON a.key=p.key "
                       "WHERE p.confidence >= ? ORDER BY a.path", (args.min_confidence,)).fetchall()
    backed = {k for (k,) in con.execute("SELECT key FROM genre_backup")}
    ok, bad = 0, []
    for key, path, genre, conf in rows:
        try:
            old = read_genre(path)
            if old == genre:
                continue
            if args.dry_run:
                print(f"  {old or '(none)':>24} -> {genre:16} ({conf:.2f})  {path}")
                ok += 1
                continue
            if key not in backed:                       # keep the very first original, even after re-runs
                con.execute("INSERT INTO genre_backup (key, path, original, written) VALUES (?,?,?,?)",
                            (key, path, old, genre))
            else:
                con.execute("UPDATE genre_backup SET written=? WHERE key=?", (genre, key))
            write_genre(path, genre)
            _touch_db(con, key, path)
            con.commit()
            ok += 1
        except Exception as e:
            con.rollback()
            bad.append((path, f"{type(e).__name__}: {e}"))
    con.close()
    print(f"{'would change' if args.dry_run else 'wrote'} {ok} files" + (f", {len(bad)} failed:" if bad else ""))
    for p, e in bad:
        print(f"  FAILED {e[:100]}  {p}")
    if ok and not args.dry_run:
        print("In Rekordbox: select these tracks → right-click → Reload Tag. (python genres.py undo restores the originals)")


def cmd_undo(args):
    con = db.connect()
    rows = con.execute("SELECT key, path, original FROM genre_backup").fetchall()
    ok, bad = 0, []
    for key, path, original in rows:
        try:
            write_genre(path, original)
            _touch_db(con, key, path)
            con.execute("DELETE FROM genre_backup WHERE key=?", (key,))
            con.commit()
            ok += 1
        except Exception as e:
            bad.append((path, f"{type(e).__name__}: {e}"))
    con.close()
    print(f"restored {ok} files" + (f", {len(bad)} failed" if bad else ""))
    for p, e in bad:
        print(f"  FAILED {e[:100]}  {p}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("eval")
    sub.add_parser("predict")
    w = sub.add_parser("write")
    w.add_argument("--dry-run", action="store_true")
    w.add_argument("--min-confidence", type=float, default=-1e9)
    sub.add_parser("undo")
    a = ap.parse_args()
    {"eval": cmd_eval, "predict": cmd_predict, "write": cmd_write, "undo": cmd_undo}[a.cmd](a)
