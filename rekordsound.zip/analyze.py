"""Analyse library audio -> data/library.db.  Resumable: re-run any time; only new or changed files
(different mtime/size) are analysed. Never writes anything to Rekordbox.

    python analyze.py                          # whole library from data/rekordbox.xml
    python analyze.py --limit 50               # first 50 un-analysed tracks (test run)
    python analyze.py --playlist "Techno"      # only tracks in playlists whose name contains this
    python analyze.py --latest 1000            # only the 1000 most recently added tracks
    python analyze.py --retry-failed           # also retry files that failed before
    python analyze.py --effnet-only            # only add discogs-effnet to already analysed tracks
Tracks analysed before discogs-effnet was added always get it (effnet only) on the next run.
"""
import argparse
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import db
import library
import energy
from models import EffnetEmbedder, Embedder, MertEmbedder, decode, embed_track, SR

PREFETCH = 3          # tracks decoded ahead while the GPU works


def todo_list(args):
    tracks, playlists, _ = library.load(args.xml)
    if args.playlist:
        want = {tid for p in playlists if args.playlist.lower() in p["path"].lower() for tid in p["track_ids"]}
        tracks = {k: v for k, v in tracks.items() if k in want}
    if args.latest:                           # N most recently added (Rekordbox DateAdded), newest first
        newest = sorted(tracks.values(), key=lambda t: (t["date_added"], int(t["id"])), reverse=True)[:args.latest]
        tracks = {t["id"]: t for t in newest}
    con = db.connect()
    done = {k: (m, s) for k, m, s in con.execute("SELECT key, mtime, size FROM audio")}
    no_eff = {k for (k,) in con.execute("SELECT key FROM audio WHERE effnet IS NULL")}
    failed = {k: m for k, m in con.execute("SELECT key, mtime FROM failed")}
    con.close()
    backfill, todo, seen, missing = [], [], set(), 0
    for t in tracks.values():
        key = library.path_key(t["path"])
        if key in seen:
            continue
        seen.add(key)
        try:
            st = os.stat(t["path"])
        except OSError:
            missing += 1
            continue
        if done.get(key) == (st.st_mtime, st.st_size):
            if key in no_eff:                    # analysed before discogs-effnet existed: add only that
                backfill.append((key, t, st, True))
            continue
        if args.effnet_only:
            continue
        if not args.retry_failed and failed.get(key) == st.st_mtime:
            continue
        todo.append((key, t, st, False))
    return backfill + todo, len(seen), missing


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", default=str(library.DEFAULT_XML))
    ap.add_argument("--limit", type=int)
    ap.add_argument("--playlist")
    ap.add_argument("--latest", type=int, help="only the N most recently added tracks")
    ap.add_argument("--retry-failed", action="store_true")
    ap.add_argument("--effnet-only", action="store_true",
                    help="only add discogs-effnet to tracks analysed before it existed")
    args = ap.parse_args()

    todo, total, missing = todo_list(args)
    if args.limit:
        todo = todo[:args.limit]
    n_eff = sum(x[3] for x in todo)
    print(f"{total} tracks, {missing} missing files, {len(todo)} to analyse"
          + (f" ({n_eff} only need discogs-effnet)" if n_eff else ""), flush=True)
    if not todo:
        return

    print("loading models…", flush=True)
    clap = mert = None
    if n_eff < len(todo):
        clap, mert = Embedder(), MertEmbedder()
    effnet = EffnetEmbedder()
    con = db.connect()
    cal = energy.calibration(con)
    pool = ThreadPoolExecutor(2)

    def load(item):
        key, t, st, _ = item
        try:
            return decode(t["path"]), None
        except Exception as e:
            return None, (getattr(e, "stderr", b"") or str(e).encode())[-300:].decode("utf-8", "replace")

    futures = {i: pool.submit(load, todo[i]) for i in range(min(PREFETCH, len(todo)))}
    t0, ok, bad = time.time(), 0, 0
    try:
        for i, (key, t, st, only_eff) in enumerate(todo):
            if i + PREFETCH < len(todo):
                futures[i + PREFETCH] = pool.submit(load, todo[i + PREFETCH])
            audio, err = futures.pop(i).result()
            if audio is not None and len(audio) < SR:
                audio, err = None, "shorter than 1 s / no audio"
            if audio is not None:
                try:
                    if only_eff:
                        db.save_effnet(con, key, embed_track(None, None, audio, effnet))
                    else:
                        r = embed_track(clap, mert, audio, effnet)
                        db.save(con, key, t["path"], st.st_mtime, st.st_size, len(audio) / SR, r)
                    f = energy.features(audio, t.get("bpm"))              # energy.py measures the same thing for old tracks
                    if f:
                        db.save_energy(con, key, st.st_mtime, st.st_size, f, energy.level_score(cal, f))
                    ok += 1
                except Exception as e:
                    err = f"{type(e).__name__}: {e}"[-300:]
            if err:
                bad += 1
                con.execute("INSERT OR REPLACE INTO failed (key, path, mtime, error) VALUES (?,?,?,?)",
                            (key, t["path"], st.st_mtime, err))
                con.commit()
            n = i + 1
            rate = (time.time() - t0) / n
            eta = rate * (len(todo) - n)
            label = f"{t['artist']} - {t['title']}"[:60]
            print(f"[{n}/{len(todo)}] {rate:.1f}s/track, ETA {eta / 3600:.1f} h  "
                  f"{'FAILED ' + err.splitlines()[-1][:80] if err else 'ok'}  {label}", flush=True)
    except KeyboardInterrupt:
        print("\ninterrupted — progress is saved, run again to continue", flush=True)
    finally:
        pool.shutdown(wait=False, cancel_futures=True)
        con.close()
    print(f"done: {ok} analysed, {bad} failed in {(time.time() - t0) / 60:.1f} min", flush=True)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
