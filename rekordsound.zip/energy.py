"""Energy estimate 1-10 per track, from the audio (numpy only, no GPU).

Per track a few features are measured on up to three 20 s windows (loudness, loudness range, onset density,
spectral brightness, low-end share, tempo) and stored in the `energy` table. The 1-10 score is a weighted sum of each
feature's percentile rank across the whole library, spread evenly over 10 levels, so it is relative to YOUR library.
It is an estimate and does not match Mixed In Key's numbers.

    python energy.py                 # compute features for all tracks that have none yet (resumable), then score
    python energy.py --limit 50      # test run
    python energy.py --recalibrate   # re-score from stored features only (after tuning WEIGHTS, or new tracks)
    python energy.py --show 30       # print a sample of tracks with their score (for checking)
"""
import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

import bpm as bpmmod

SR = 48000
WINDOW = 20 * SR
NFFT = 2048
HOP = 1024
FEATS = ["loud_mean", "loud_p90", "range", "onset", "centroid", "high", "low", "bpm"]
# weight of each feature's percentile rank; "range" counts inverted (steady, loud tracks = more energy)
WEIGHTS = {"loud_mean": 0.15, "loud_p90": 0.15, "range": -0.10, "onset": 0.20, "centroid": 0.075, "high": 0.075,
           "low": 0.10, "bpm": 0.15}


def _windows(audio):
    n = len(audio)
    if n <= 3 * WINDOW:
        return [audio]
    return [audio[int(n * f) - WINDOW // 2:int(n * f) + WINDOW // 2] for f in (0.2, 0.5, 0.8)]


def features(audio, bpm=None):
    """audio: mono float32 at 48 kHz -> dict of FEATS, or None when the audio is too short / silent."""
    audio = np.asarray(audio, np.float32)
    if len(audio) < 4 * SR:
        return None
    db, cen, high, low, ons = [], [], [], [], []
    win = np.hanning(NFFT).astype(np.float32)
    freqs = np.fft.rfftfreq(NFFT, 1 / SR)
    hi_m, lo_m = freqs >= 4000, freqs < 150
    for w in _windows(audio):
        step = SR // 10                                        # 100 ms loudness frames
        nf = len(w) // step
        if nf < 10:
            continue
        rms = np.sqrt((w[:nf * step].reshape(nf, step) ** 2).mean(1) + 1e-12)
        d = 20 * np.log10(rms)
        db.append(d[d > -50])
        nfr = 1 + (len(w) - NFFT) // HOP
        idx = np.arange(NFFT)[None, :] + HOP * np.arange(nfr)[:, None]
        p = np.abs(np.fft.rfft(w[idx] * win, axis=1)) ** 2
        tot = p.sum() + 1e-12
        cen.append(float((p.sum(0) * freqs).sum() / tot))
        high.append(float(p[:, hi_m].sum() / tot))
        low.append(float(p[:, lo_m].sum() / tot))
        env, fps = bpmmod.onset_envelope(w)
        if env is not None:
            thr = env.mean() + env.std()
            pk = (env[1:-1] > env[:-2]) & (env[1:-1] >= env[2:]) & (env[1:-1] > thr)
            ons.append(float(pk.sum() / (len(env) / fps)))
    db = np.concatenate(db) if db else np.array([])
    if len(db) < 20 or not ons:
        return None
    if not bpm:                                                # tempo from the middle of the track
        mid = len(audio) // 2
        bpm, _ = bpmmod.estimate_bpm(audio[mid - 20 * SR:mid + 20 * SR])
    return dict(loud_mean=float(db.mean()), loud_p90=float(np.percentile(db, 90)),
                range=float(np.percentile(db, 90) - np.percentile(db, 10)), onset=float(np.mean(ons)),
                centroid=float(np.mean(cen)), high=float(np.mean(high)), low=float(np.mean(low)),
                bpm=float(bpm) if bpm else None)


class Calibration:
    """Percentile tables of a feature matrix (library) -> 1-10 score of any feature dict."""

    def __init__(self, rows):
        self.cols = {}
        for f in FEATS:
            v = np.array([r[f] for r in rows if r.get(f) is not None], float)
            self.cols[f] = np.sort(v)
        s = np.array([self._raw(r) for r in rows])
        self.s = np.sort(s)

    def _pct(self, f, x):
        c = self.cols[f]
        return 0.5 if x is None or len(c) == 0 else float(np.searchsorted(c, x) / len(c))

    def _raw(self, r):
        return sum(abs(w) * ((1 - self._pct(f, r.get(f))) if w < 0 else self._pct(f, r.get(f)))
                   for f, w in WEIGHTS.items()) / sum(abs(w) for w in WEIGHTS.values())

    def score(self, feat):
        """-> energy 1.0-10.0 (continuous; round for the level)."""
        if not feat or len(self.s) == 0:
            return None
        p = float(np.searchsorted(self.s, self._raw(feat))) / len(self.s)
        return round(1 + 9.999 * p, 2)


def level(score):
    return None if score is None else int(min(10, max(1, score)))      # 1.00-1.99 -> 1 ... 10.0 -> 10


def level_score(cal, feat):
    """Score of a new track against an existing calibration (None when there is none yet)."""
    return cal.score(feat) if cal else None


def calibration(con):
    import db
    rows = [f for _, f, _ in db.load_energy(con)]
    return Calibration(rows) if len(rows) >= 50 else None


def main():
    import db
    import library
    from models import decode
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", default=str(library.DEFAULT_XML))
    ap.add_argument("--limit", type=int)
    ap.add_argument("--recalibrate", action="store_true", help="only re-score from stored features")
    ap.add_argument("--show", type=int, help="print N sample tracks with their score")
    ap.add_argument("--playlist")
    args = ap.parse_args()
    con = db.connect()
    tracks, playlists, _ = library.load(args.xml)
    by_key = {library.path_key(t["path"]): t for t in tracks.values()}

    if not args.recalibrate and not args.show:
        if args.playlist:
            want = {tid for p in playlists if args.playlist.lower() in p["path"].lower() for tid in p["track_ids"]}
            by_key = {k: t for k, t in by_key.items() if t["id"] in want}
        have = {k: (m, s) for k, m, s, *_ in con.execute("SELECT key, mtime, size FROM energy")}
        failed = {k for (k,) in con.execute("SELECT key FROM failed")}
        todo = []
        for k, t in by_key.items():
            if k in failed:
                continue
            try:
                st = os.stat(t["path"])
            except OSError:
                continue
            if have.get(k) != (st.st_mtime, st.st_size):
                todo.append((k, t, st))
        if args.limit:
            todo = todo[:args.limit]
        print(f"{len(by_key)} tracks, {len(todo)} to measure", flush=True)

        def load(item):
            try:
                return decode(item[1]["path"]), None
            except Exception as e:
                return None, str(getattr(e, "stderr", e))[-200:]
        pool = ThreadPoolExecutor(3)
        fut = {i: pool.submit(load, todo[i]) for i in range(min(4, len(todo)))}
        t0, ok = time.time(), 0
        try:
            for i, (k, t, st) in enumerate(todo):
                if i + 4 < len(todo):
                    fut[i + 4] = pool.submit(load, todo[i + 4])
                audio, err = fut.pop(i).result()
                f = None if audio is None else features(audio, t.get("bpm"))
                if f is not None:
                    db.save_energy(con, k, st.st_mtime, st.st_size, f, None)
                    ok += 1
                if (i + 1) % 100 == 0 or i + 1 == len(todo):
                    rate = (time.time() - t0) / (i + 1)
                    print(f"[{i + 1}/{len(todo)}] {rate:.2f}s/track, ETA {rate * (len(todo) - i - 1) / 3600:.1f} h", flush=True)
        except KeyboardInterrupt:
            print("interrupted - progress is saved, run again to continue", flush=True)
        finally:
            pool.shutdown(wait=False, cancel_futures=True)
        print(f"measured {ok} tracks in {(time.time() - t0) / 60:.1f} min", flush=True)

    cal = calibration(con)
    if cal is None:
        print("fewer than 50 tracks measured: nothing to score yet")
        return
    rows = db.load_energy(con)
    con.executemany("UPDATE energy SET score=? WHERE key=?", [(cal.score(f), k) for k, f, _ in rows])
    con.commit()
    sc = [level(cal.score(f)) for _, f, _ in rows]
    print("scored", len(rows), "tracks; levels 1-10:", [sc.count(i) for i in range(1, 11)])
    if args.show:
        import random
        random.seed(2)
        for k, f, s in random.sample(rows, min(args.show, len(rows))):
            t = by_key.get(k)
            print(f"{cal.score(f):5.1f}  loud {f['loud_mean']:6.1f}  onset {f['onset']:5.1f}  bpm {f['bpm'] or 0:5.1f}  "
                  f"{(t['artist'] + ' - ' + t['title']) if t else k}"[:130])


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
